"""Reprodução do treinamento YOLO11s640 registrado no Colab."""
from pathlib import Path
import argparse,json,shutil,hashlib
import yaml,torch
from ultralytics import YOLO

def treinar(dados,saida,epocas=80,tamanho=640,lote=8,dispositivo='cpu'):
    saida.mkdir(parents=True,exist_ok=True)
    d=yaml.safe_load(dados.read_text());d['path']=str(dados.parent.resolve())
    y=saida/'dados_treino.yaml';y.write_text(yaml.safe_dump(d,sort_keys=False))
    m=YOLO('yolo11s.pt')
    m.train(data=str(y.resolve()),epochs=epocas,imgsz=tamanho,batch=lote,device=dispositivo,
            seed=2026,deterministic=True,workers=2,optimizer='AdamW',lr0=.0007,
            warmup_epochs=2,patience=18,freeze=0,mosaic=.35,mixup=0,close_mosaic=10,
            degrees=0,translate=.06,hsv_h=.012,hsv_s=.4,hsv_v=.22,fliplr=.5,
            project=str(saida.resolve()),name='treino',exist_ok=False,plots=True,amp=True)
    shutil.copyfile(m.trainer.best,saida/'best.pt')
    cfg=dict(modelo='YOLO11s',imgsz=tamanho,imgsz_treino=tamanho,epochs_max=epocas,
             batch=lote,device_train=str(dispositivo),epocas_executadas=m.trainer.epoch+1,
             sha256_best=hashlib.sha256((saida/'best.pt').read_bytes()).hexdigest())
    (saida/'treino_config.json').write_text(json.dumps(cfg,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dados',type=Path,required=True);p.add_argument('--saida',type=Path,required=True)
    p.add_argument('--epocas',type=int,default=80);p.add_argument('--imgsz',type=int,default=640)
    p.add_argument('--lote',type=int,default=8);p.add_argument('--dispositivo',default='0'if torch.cuda.is_available()else'cpu')
    a=p.parse_args();treinar(a.dados,a.saida,a.epocas,a.imgsz,a.lote,a.dispositivo)
