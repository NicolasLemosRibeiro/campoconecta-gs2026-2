"""Submete imagens em sequência ao mesmo endpoint usado pelo CampoConecta."""
import argparse
import csv
import io
import json
import statistics
import time
from pathlib import Path

import requests
from PIL import Image, ImageDraw, ImageFont, ImageOps


def processar(api, entradas, destino):
    if not entradas:
        raise ValueError("A pasta deve conter imagens JPG ou PNG.")
    destino.mkdir(parents=True, exist_ok=True)
    url = f"{api.rstrip('/')}/modulos/visao/analisar"
    resultados = []
    with requests.Session() as sessao:
        for ordem, caminho in enumerate(entradas, 1):
            conteudo = caminho.read_bytes()
            tipo = "image/png" if caminho.suffix.lower() == ".png" else "image/jpeg"
            inicio = time.perf_counter()
            resposta = sessao.post(url, files={"imagem": (caminho.name, conteudo, tipo)}, timeout=60)
            resposta.raise_for_status()
            dados = resposta.json()
            tempo_http_ms = 1000 * (time.perf_counter() - inicio)
            if not dados["disponivel"]:
                raise RuntimeError(dados["mensagem"])
            resultados.append({
                "quadro": ordem, "arquivo": caminho.name, "deteccoes": len(dados["caixas"]),
                "maior_confianca": dados["confianca"], "latencia_api_ms": dados["latencia_ms"],
                "latencia_http_ms": round(tempo_http_ms, 2),
            })
            with Image.open(io.BytesIO(conteudo)) as origem:
                imagem = ImageOps.exif_transpose(origem).convert("RGB")
            escala = min(800 / imagem.width, 500 / imagem.height)
            imagem = imagem.resize((round(imagem.width*escala), round(imagem.height*escala)))
            quadro = Image.new("RGB", (960, 600), "#142522")
            ox, oy = (960 - imagem.width) // 2, (535 - imagem.height) // 2 + 38
            quadro.paste(imagem, (ox, oy))
            draw = ImageDraw.Draw(quadro)
            fonte = ImageFont.load_default(size=19)
            for caixa in dados["caixas"]:
                x, y = ox + caixa["x"]*escala, oy + caixa["y"]*escala
                w, h = caixa["largura"]*escala, caixa["altura"]*escala
                draw.rectangle((x, y, x+w, y+h), outline="#44ffc0", width=3)
                y_rotulo = max(oy, y-24)
                texto = f'Buraco {caixa["confianca"]:.0%}'
                draw.rectangle((x, y_rotulo, x+draw.textlength(texto, font=fonte)+9, y_rotulo+23), fill="#12362d")
                draw.text((x+4, y_rotulo), texto, font=fonte, fill="white")
            draw.text((35, 13), f"CampoConecta | Sequência de teste | Quadro {ordem:02d}/{len(entradas):02d}",
                      font=ImageFont.load_default(size=22), fill="white")
            draw.text((35, 565), f'{caminho.name}  |  {len(dados["caixas"])} deteccao(oes)  |  {tempo_http_ms:.0f} ms via HTTP',
                      font=fonte, fill="#e6f4ef")
            quadro.save(destino / f"quadro_{ordem:03d}.png")
    with (destino / "sequencia.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=resultados[0].keys())
        writer.writeheader()
        writer.writerows(resultados)
    quentes = [r["latencia_http_ms"] for r in resultados[1:]] or [resultados[0]["latencia_http_ms"]]
    resumo = {
        "total_quadros": len(resultados), "quadros_pos_aquecimento": len(quentes),
        "media_http_ms_pos_aquecimento": round(statistics.mean(quentes), 2),
        "fps_http_pos_aquecimento": round(len(quentes) * 1000 / sum(quentes), 2),
    }
    (destino / "sequencia_resumo.json").write_text(json.dumps(resumo, indent=2), encoding="utf-8")
    print(json.dumps(resumo, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api", default="http://127.0.0.1:8000")
    parser.add_argument("--imagens", type=Path, required=True)
    parser.add_argument("--saida", type=Path, default=Path("sequencia_resultados"))
    args = parser.parse_args()
    arquivos = sorted(p for p in args.imagens.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    processar(args.api, arquivos, args.saida)
