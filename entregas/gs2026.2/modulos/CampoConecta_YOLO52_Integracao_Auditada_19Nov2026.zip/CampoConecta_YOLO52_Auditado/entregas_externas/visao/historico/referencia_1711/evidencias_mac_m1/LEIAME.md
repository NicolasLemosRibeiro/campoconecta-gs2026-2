# Execução local no Mac M1

Execução de 17/11/2026 no MacBook Air M1 do grupo, Python 3.12.16. A interface e a API foram iniciadas localmente. A sequência utiliza o mesmo endpoint da interface.

Foram processadas 12 imagens. Descartando a primeira requisição como aquecimento, as 11 seguintes tiveram média HTTP de 54,15 ms, equivalente a 18,47 imagens/s nas chamadas sequenciais. Essa taxa exclui desenho, gravação dos quadros e reprodução na interface; não representa FPS de captura de câmera. A amostra é curta e não mede capacidade sob concorrência.

Imagens de origem: 720 × 720 pixels; entrada do detector: 384 × 384; quadros de apresentação: 960 × 600. As métricas de qualidade do relatório pertencem ao conjunto de teste, não a esta sequência de demonstração. O hardware e os tempos desta execução diferem dos ambientes de referência do relatório.

Os arquivos sequencia.csv e sequencia_resumo.json foram preservados byte a byte do ZIP enviado pelo integrante. Os 12 quadros foram preservados acima do rodapé; apenas o texto inferior foi refeito com caracteres compatíveis com a fonte. Não houve nova inferência, alteração das caixas, das confianças ou dos tempos medidos. O script sequencia_api.py recebeu a mesma correção de texto para próximas execuções.

Conferência na interface: India_008389.jpg apresentou uma sinalização com confiança de 59,23%; India_000145.jpg não apresentou sinalizações no limiar atual. A ausência de sinalização não comprova ausência de dano.
