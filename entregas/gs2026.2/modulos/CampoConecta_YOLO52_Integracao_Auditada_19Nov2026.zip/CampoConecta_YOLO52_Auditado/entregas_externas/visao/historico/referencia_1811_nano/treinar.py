"""Reproduz o ajuste do detector selecionado; avaliação é feita separadamente."""
import argparse,hashlib,json,shutil
from pathlib import Path
import torch
from ultralytics import YOLO

def treinar(dados,pesos_iniciais,saida,epocas,dispositivo,tamanho,lote):
    modulo=Path(__file__).resolve().parent
    referencia=json.loads((modulo/'config_treinamento.json').read_text())
    parametros=referencia['config'].copy()
    parametros.update(epochs=epocas,device=dispositivo,imgsz=tamanho,batch=lote)
    origem=Path(pesos_iniciais) if pesos_iniciais else modulo/referencia['pesos_iniciais_relativo']
    saida.mkdir(parents=True,exist_ok=True)
    modelo=YOLO(str(origem))
    modelo.add_callback('on_train_start',lambda t:torch.set_num_threads(4))
    modelo.train(data=str(dados.resolve()),project=str(saida.resolve()),name='treino',exist_ok=False,**parametros)
    shutil.copyfile(modelo.trainer.best,saida/'best.pt')
    meta=dict(modelo=referencia['modelo'],imgsz=referencia['resolucao_inferencia'],imgsz_treino=tamanho,
              seed=parametros['seed'],epochs_max=epocas,batch=lote,device_train=dispositivo,
              pesos_iniciais=origem.name,continuidade=referencia['continuidade'],config_continuidade=parametros,
              sha256_best=hashlib.sha256((saida/'best.pt').read_bytes()).hexdigest())
    (saida/'treino_config.json').write_text(json.dumps(meta,indent=2))
    print('Checkpoint escolhido na validação:',saida/'best.pt')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dados',type=Path,required=True)
    p.add_argument('--pesos-iniciais',default=None)
    p.add_argument('--saida',type=Path,default=Path('resultados_visao'))
    p.add_argument('--epocas',type=int,default=60)
    p.add_argument('--dispositivo',default='0'if torch.cuda.is_available()else'cpu')
    p.add_argument('--imgsz',type=int,default=384)
    p.add_argument('--lote',type=int,default=12)
    a=p.parse_args();treinar(a.dados,a.pesos_iniciais,a.saida,a.epocas,a.dispositivo,a.imgsz,a.lote)
