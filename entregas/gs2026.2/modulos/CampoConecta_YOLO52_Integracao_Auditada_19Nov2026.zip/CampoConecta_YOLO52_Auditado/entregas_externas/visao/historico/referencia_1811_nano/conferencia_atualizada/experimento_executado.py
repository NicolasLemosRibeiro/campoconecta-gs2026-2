"""Tentativa controlada: continuação YOLO11n e resolução escolhidas só na validação."""
import os
os.environ['OMP_NUM_THREADS']='4'
os.environ['MKL_NUM_THREADS']='4'
os.environ['YOLO_AUTOINSTALL']='false'
from pathlib import Path
import json,time,hashlib,shutil,sys,subprocess,zipfile,csv
import torch
from ultralytics import YOLO
R=Path(__file__).resolve().parent
C=R/'CampoConecta';V=C/'entregas_externas/visao';D=V/'amostra_rdd2022';W=C/'backend/app/modulos/pesos_visao/best.pt';E=R/'experimento';E.mkdir(exist_ok=True)
sys.path.insert(0,str(V));from avaliar import inferir,metricas,LIMIARES,principal
RESOLUCOES=[384,512,640]
cfg=dict(epochs=60,imgsz=384,batch=12,device='cpu',seed=2026,deterministic=True,workers=0,
 optimizer='AdamW',lr0=0.0003,lrf=0.1,nbs=16,warmup_epochs=1,warmup_bias_lr=0.0,
 patience=15,freeze=4,amp=False,mosaic=0.0,mixup=0.0,degrees=0.0,translate=0.08,
 scale=0.25,hsv_h=0.012,hsv_s=0.45,hsv_v=0.25,fliplr=0.5,cos_lr=True,plots=True,verbose=False,cache='ram',save_period=-1)
protocolo=dict(objetivo='Melhorar F1, precisão e recall sem mudar dados ou contrato da API.',origem_sha256=hashlib.sha256(W.read_bytes()).hexdigest(),config=cfg,resolucoes_validacao=RESOLUCOES,selecao='Checkpoint de treino por mAP50-95 de validação. Entre pesos e resoluções, maior F1 de validação; limiar pelo F1, sem olhar teste.',adocao='No teste conhecido, F1 deve melhorar pelo menos 2 pontos percentuais, sem redução de precisão nem recall. Não escolher outro candidato depois de consultar teste.',limitacao='O teste já foi examinado em etapas anteriores. Não é confirmação independente em novas vias.',gpu_disponivel=torch.cuda.is_available())
(E/'protocolo.json').write_text(json.dumps(protocolo,ensure_ascii=False,indent=2))
yaml=E/'desenvolvimento.yaml';yaml.write_text(f'path: {D.resolve()}\ntrain: images/train\nval: images/val\nnames:\n  0: buraco\n')
torch.set_num_threads(4)

def avaliar_val(pesos,nome):
 m=YOLO(str(pesos));items=[]
 for res in RESOLUCOES:
  torch.set_num_threads(4);inicio=time.time();amostras=inferir(m,D,'val',res,'cpu');grade=[metricas(amostras,t)for t in LIMIARES]
  melhor=max(grade,key=lambda x:(x['f1'],x['recall'],x['limiar']))
  items.append(dict(pesos=str(pesos),nome=nome,imgsz=res,melhor=melhor,grade=grade,segundos=round(time.time()-inicio,2)))
  print('VALIDACAO',nome,res,json.dumps(melhor),flush=True)
 (E/f'validacao_{nome}.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
 return items

STATE=E/'library_state.json'
def salvar(trainer=None,final=False):
 ep=trainer.epoch+1 if trainer else 0
 if trainer and not final and ep not in [5,15,30,45,60]:return
 archive=E/'Visao_Checkpoint_Continuidade_1811.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=3)as z:
  z.write(Path(__file__),'experimento.py')
  for f in E.glob('*.json'):
   if f.name!='library_state.json':z.write(f,f.name)
  if trainer:
   for f in [trainer.last,trainer.best,trainer.csv,trainer.save_dir/'args.yaml']:
    if Path(f).is_file():z.write(f,Path('treino')/Path(f).relative_to(trainer.save_dir))
  z.writestr('LEIAME.md','Checkpoint de uma tentativa em andamento. Não é modelo aprovado. Use resultado_final.json, quando existir, para saber se houve melhora comprovada. Os dados e o checkpoint inicial estão no pacote GS_Visao_CampoConecta_Final.zip preservado. O script permite reconstruir os ajustes e registra os caminhos do ambiente original.\n')
 item={'local_path':str(archive),'purpose':'create_library_file','library_artifact_type':'other'}
 if STATE.exists():
  state=json.loads(STATE.read_text());item={'local_path':str(archive),'purpose':'replace_library_file','library_file_id':state['library_file_id'],'expected_current_version':state['version'],'version_reason':f'Checkpoint real após época {ep}; final={final}.'}
 p=subprocess.run([sys.executable,str(R/'helpers/library_upload.py')],input=json.dumps({'uploads':[item]}),text=True,capture_output=True)
 (E/f'salvamento_{ep:03d}_{int(final)}.log').write_text(p.stdout+'\n'+p.stderr)
 if p.returncode:raise RuntimeError('Não foi possível preservar checkpoint: '+p.stderr[-500:])
 lines=[l for l in p.stdout.splitlines()if l.startswith('{"results"')]
 if not lines:raise RuntimeError('Salvamento sem confirmação; treino interrompido para preservar trabalho.')
 rr=json.loads(lines[-1])['results'][0]
 if rr['status']!='succeeded':raise RuntimeError('Checkpoint não foi salvo: '+str(rr))
 STATE.write_text(json.dumps(dict(library_file_id=rr['library_file_id'],version=rr['current_version_number'],epoca=ep,final=final),indent=2))
 print('CHECKPOINT_PRESERVADO',ep,'final',final,flush=True)

print('INICIO_VALIDACAO_REFERENCIA',flush=True)
base=avaliar_val(W,'referencia')
print('INICIO_TREINO',flush=True)
m=YOLO(str(W));m.add_callback('on_train_start',lambda t:torch.set_num_threads(4));m.add_callback('on_model_save',salvar)
m.add_callback('on_train_end',lambda t:salvar(t,final=True))
m.train(data=str(yaml),project=str(E),name='continuacao',exist_ok=False,**cfg)
novos=avaliar_val(Path(m.trainer.best),'continuidade')
todos=base+novos;escolhido=max(todos,key=lambda x:(x['melhor']['f1'],x['melhor']['precisao'],x['melhor']['recall']));referencia=next(x for x in base if x['imgsz']==384)
resumo=dict(status='validacao_concluida',referencia_validacao=referencia,selecionado=escolhido,candidatos=todos,protocolo=protocolo,adotar=False)
if escolhido['melhor']['f1']>referencia['melhor']['f1']:
 A=E/'avaliacao';A.mkdir(exist_ok=True)
 shutil.copyfile(escolhido['pesos'],A/'best.pt')
 config=json.loads((V/'resultados/treino_config.json').read_text());config.update(imgsz=escolhido['imgsz'],sha256_best=hashlib.sha256((A/'best.pt').read_bytes()).hexdigest(),pesos_iniciais='baseline_1711.pt'if escolhido['nome']=='continuidade'else'checkpoint_preservado.pt',continuidade=escolhido['nome']=='continuidade',config_continuidade=cfg if escolhido['nome']=='continuidade'else None)
 (A/'treino_config.json').write_text(json.dumps(config,indent=2))
 for nome in ['images','labels']:(A/nome).symlink_to(D/nome,target_is_directory=True)
 dados=A/'dados.yaml';dados.write_text(f'path: {D.resolve()}\ntrain: images/train\nval: images/val\ntest: images/test\nnames:\n  0: buraco\n')
 principal(dados,A/'best.pt',A,'cpu')
 a=json.loads((V/'resultados/metricas.json').read_text());b=json.loads((A/'metricas.json').read_text());aa=a['teste'];bb=b['teste']
 ganho=bb['f1']>=aa['f1']+0.02 and bb['precisao']>=aa['precisao'] and bb['recall']>=aa['recall']
 resumo.update(status='avaliacao_concluida',referencia_teste=aa,novo_teste=bb,novas_metricas=b,adotar=ganho)
(E/'resultado_final.json').write_text(json.dumps(resumo,ensure_ascii=False,indent=2)+'\n')
salvar(m.trainer,final=True)
print('RESULTADO_FINAL',json.dumps({k:v for k,v in resumo.items()if k not in ['candidatos','protocolo','selecionado','referencia_validacao']}),flush=True)
