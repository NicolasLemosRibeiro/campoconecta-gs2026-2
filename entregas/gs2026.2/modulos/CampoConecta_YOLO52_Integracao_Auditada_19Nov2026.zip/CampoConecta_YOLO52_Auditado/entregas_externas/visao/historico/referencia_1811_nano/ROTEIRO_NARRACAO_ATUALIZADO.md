# Roteiro atualizado de Visão Computacional

Este roteiro corresponde aos novos pesos YOLO11n. As capturas e os áudios antigos com métricas diferentes precisam ser atualizados. O vídeo deve mostrar a aplicação real em uso. Use uma captura da introdução do notebook, a preparação dos dados, o treinamento registrado, a avaliação e a interface com os novos pesos.

## 1 — Apresentação e problema

Olá, somos Pedro Leal Murad, Murilo Benhossi e Nicolas Lemos Ribeiro. Este é o módulo de Visão Computacional do CampoConecta, desenvolvido para a Global Solution. Buracos nas vias podem dificultar o acesso às comunidades rurais. Nosso protótipo analisa fotografias e sinaliza possíveis buracos para apoiar a seleção dos locais que merecem vistoria.

## 2 — Dados e arquitetura

Usamos uma amostra de 480 imagens da Índia, do RDD2022, com anotações de buracos da classe D40. São 300 imagens para treino, 80 para validação e 100 para teste. O detector selecionado é o YOLO11n. O treinamento, seus parâmetros e sua curva estão registrados no notebook e nos arquivos do projeto. Comparamos modelos e resoluções usando a validação antes de conferir o candidato escolhido no teste conhecido.

## 3 — Demonstração com sinalização

Na aba Módulos, enviamos uma fotografia da via para análise. A aplicação mostra a região sinalizada, a confiança do detector e uma sugestão de vistoria para revisão humana. Essa confiança é uma pontuação do modelo; ela não mede a gravidade do dano nem equivale à precisão global do sistema.

## 4 — Demonstração sem sinalização

Neste outro exemplo, nenhuma caixa foi exibida no limiar adotado. Isso não garante que a via esteja livre de danos. A iluminação, o enquadramento e o tamanho do buraco podem afetar o resultado. Por isso, mantemos a mensagem de limitação e a necessidade de avaliação pela equipe responsável.

## 5 — Integração e desempenho

A interface envia a imagem à API e recebe as caixas, a confiança e a mensagem de triagem. O formato da resposta foi mantido para preservar a integração com os demais módulos. Também verificamos uma sequência de doze imagens pela API. O relatório identifica o ambiente e o método das medições; o tempo pode variar conforme o computador. Esse teste com fotografias não equivale à avaliação de um fluxo de vídeo completo.

## 6 — Avaliação e conclusão

No teste conhecido, o modelo registrou 37,8 por cento de precisão, 34,6 por cento de recall e 36,1 por cento de F1. O relatório compara esses resultados com a versão anterior e apresenta exemplos de acertos, falsos positivos e falsos negativos. O teste já havia sido consultado em etapas anteriores, portanto ainda precisamos de uma avaliação independente em novas vias. O resultado é um protótipo de triagem, com revisão humana e limites documentados.

## Orientações de captura

- Reinicie a API depois de substituir os pesos e a configuração.
- Use `demonstracao/imagens/India_008389.jpg` para o exemplo com sinalização e `India_000145.jpg` para o exemplo sem sinalização.
- Nesta execução Linux, o primeiro exemplo retornou confiança de 57,8%. Confira o valor exibido na sua execução antes de mencionar qualquer número no vídeo.
- Mostre as tabelas e as figuras do notebook atualizado, preservando a identificação dos erros do modelo.
- As medições antigas do Mac pertencem aos pesos anteriores. Grave a nova sequência se quiser apresentar tempos do Mac.
- Os textos acima não prometem aprovação, desempenho autônomo ou detecção de todos os buracos.
