"""Treina YOLO11n inicializado com pesos COCO e avalia o checkpoint em teste separado."""
import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("MKL_NUM_THREADS", "4")

import torch
from ultralytics import YOLO

SEMENTE = 2026


def treinar(dados, pesos_iniciais, saida, epocas, dispositivo, tamanho, lote):
    torch.set_num_threads(min(4, torch.get_num_threads()))
    modelo = YOLO(str(pesos_iniciais))
    modelo.train(
        data=str(dados.resolve()), epochs=epocas, imgsz=tamanho, batch=lote,
        device=dispositivo, seed=SEMENTE, deterministic=True, workers=0,
        project=str(saida.resolve()), name="treino", exist_ok=False,
        optimizer="AdamW", lr0=0.001, nbs=16, warmup_epochs=2, patience=6, freeze=4, amp=False,
        mosaic=0.0, mixup=0.0, degrees=0.0, translate=0.08,
        hsv_h=0.012, hsv_s=0.45, hsv_v=0.25, fliplr=0.5,
        plots=True, verbose=True,
    )
    origem = Path(modelo.trainer.best)
    destino = saida / "best.pt"
    shutil.copyfile(origem, destino)
    metadados = {
        "imgsz": tamanho, "seed": SEMENTE, "epochs_max": epocas, "batch": lote,
        "device_train": dispositivo,
        "pesos_iniciais": Path(pesos_iniciais).name,
        "sha256_best": hashlib.sha256(destino.read_bytes()).hexdigest(),
    }
    (saida / "treino_config.json").write_text(json.dumps(metadados, indent=2), encoding="utf-8")
    print(f"Checkpoint selecionado na validação: {destino}")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dados", type=Path, required=True)
    p.add_argument("--pesos-iniciais", default="yolo11n.pt")
    p.add_argument("--saida", type=Path, default=Path("resultados_visao"))
    p.add_argument("--epocas", type=int, default=20)
    p.add_argument("--dispositivo", default="0" if torch.cuda.is_available() else "cpu")
    p.add_argument("--imgsz", type=int, default=384)
    p.add_argument("--lote", type=int, default=12)
    a = p.parse_args()
    treinar(a.dados, a.pesos_iniciais, a.saida, a.epocas, a.dispositivo, a.imgsz, a.lote)
