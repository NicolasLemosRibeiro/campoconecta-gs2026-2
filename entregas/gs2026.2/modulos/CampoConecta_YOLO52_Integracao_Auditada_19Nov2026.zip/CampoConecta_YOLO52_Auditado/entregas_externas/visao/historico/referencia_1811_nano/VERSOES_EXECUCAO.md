# Ambiente da execução

Python 3.12; PyTorch 2.7.1+cpu; torchvision 0.22.1+cpu; Ultralytics 8.3.232; NumPy 2.2.6; OpenCV 4.12.0.

O treinamento desta tentativa ocorreu em CPU Linux, com quatro threads no PyTorch. A arquitetura, a resolução, a semente e os parâmetros exatos constam em config_treinamento.json e no protocolo. Uma nova execução em outro ambiente pode variar.
