# Auditoria técnica da integração — 19/11/2026

## Base e identidade

Foi utilizado exclusivamente o ZIP GS_Visao_CampoConecta_Mac_Execucao_Final.zip, com 1.381 entradas. O hash dos pesos ativos coincide com `config.sha256_best` do experimento YOLO11s: `2e0464c17a6f76349e03389d0e0739623945ef4c81ffcf4ba84c1ae4d072ba62`. Os pesos históricos presentes na pasta historico não foram adotados. Não ocorreu treinamento nem troca de checkpoint.

## Falha de integração: fatos e limites

O carregador original capturava ImportError e AttributeError e retornava None. Assim, um módulo presente com dependência ausente ou função analisar ausente podia ser apresentado como “ainda não integrado”. O arquivo real do ZIP importou normalmente e executou uma inferência real neste ambiente. Portanto, não há evidência suficiente para atribuir a falha específica do Mac a uma dependência ou linha concreta. Também não há fundamento para afirmar que o checkpoint estava corrompido.

A correção preserva a causa da exceção e registra o traceback no backend. A rota mantém o contrato e distingue falha de carregamento de falha de inferência. O diagnóstico identifica o executável Python e o arquivo efetivamente importado, verifica pesos e ajustes e exige uma detecção real. O iniciador executa esse diagnóstico antes de anunciar o sistema pronto. Extrair em uma pasta nova e reiniciar a API evita continuar com código antigo em memória; isso é uma medida operacional, não uma causa local comprovada.

## Reavaliação

As 80 imagens de validação e 100 de teste conhecido reproduziram exatamente as contagens e AP do arquivo original. No ponto operacional de confiança 0,25 e IoU de associação 0,50: validação TP30/FP28/FN63, precisão51,72%, recall32,26%, F139,74%; teste TP35/FP32/FN72, precisão52,24%, recall32,71%, F140,23%. AP@50=38,31% e mAP@50–95=12,30%. A precisão48,45% do resumo padrão do Colab é outro ponto da curva; não corresponde a troca dos pesos. A confiança85,52% é apenas da caixa do exemplo India_008389.jpg.

O teste já havia sido consultado e não é uma validação independente. O manifesto e o protocolo da amostra foram preservados. A auditoria presente não demonstra independência por local ou por vídeo de origem nem desempenho em novas vias; não se afirma ausência de todo vazamento perceptual.

## Testes e evidências

- Testes do backend, incluindo cenários de importação ausente, função não chamável e preservação dos módulos opcionais: backend_final.log.
- Oito testes existentes de frontend, com dublês de API nos cenários isolados: frontend.log.
- Importação, identidade, contrato VisaoSaida e uma detecção real: diagnostico_real.json e diagnóstico do fluxo.
- Servidores FastAPI e Streamlit por HTTP, imagens positiva/negativa/inválida: fluxo_teste_integracao.json.
- Upload pelo widget do AppTest, submissão do formulário e renderização de imagem/tabela com API e YOLO reais: fluxo_tela_visao_real.log. Não há substituição de resposta ou detector nesse fluxo.
- Doze imagens reais submetidas ao endpoint: sequencia_http/sequencia.csv, sequencia_resumo.json e quadros PNG.
- Reavaliação exata: metricas_reproduzidas.json e reavaliacao.log.

As falhas técnicas de importação usadas nas regressões são induzidas somente nos testes. O código de produção executa o YOLO. Os testes detectaram e corrigiram um nome de elemento usado pela própria verificação automatizada da tela; a conferência final usou o widget de upload do Streamlit e o elemento image da versão instalada.

## Atendimento ao enunciado consultado

Fonte: PDF FIAP “2TIAP(F-Y)-2026 - GS 2026.2”, disciplina09, Visão Computacional, página com número30. O enunciado solicita processamento de imagens no protótipo CitizenTech, precisão, desempenho em tempo real e justificativa arquitetural para manutenção urbana.

| Critério | Evidência | Limite |
|---|---|---|
| Processamento integrado | API, formulário e caixas D40 reais | Conferência nativa no Mac pendente |
| Precisão | Validação/teste, TP/FP/FN, AP, erros no notebook e PDF | Teste conhecido; recall operacional de32,71% |
| Desempenho | Inferência em CPU e sequência HTTP com FPS medidos | Não é câmera ao vivo; tempos não são do Mac |
| Arquitetura | YOLO11s COCO, transferência, entrada640, treino64épocas/seleçãoépoca46 documentados | Repetição pode variar por ambiente |
| Resultado visual | Caixas, confiança, exemplos de acertos e erros | Confiança não mede gravidade |
| Vídeo/apresentação | Sequência real preservada e atualizada nesta conferência | Vídeo narrado final será entregue depois |

Não foi encontrado nesse trecho um percentual mínimo obrigatório nem exigência de uma versão específica do YOLO. Regras complementares do portal da disciplina não foram verificadas. A nota não pode ser garantida. A detecção de danos na pavimentação apoia manutenção de infraestrutura viária; a aceitação desse recorte temático deve seguir a orientação do professor.

## Ambiente e preservação

Execução de conferência em Linux/Python3.12, Torch2.7.1+cpu, Ultralytics8.4.215, NumPy1.26.4, OpenCV4.11.0.86 e PyArrow17.0.0 no fluxo final. A configuração macOS original fixa outro build de Torch; a instalação nativa no M1 não foi executada. pip check informado pelo usuário não substitui os testes reais, e não é apresentado aqui como comando executado no Mac pelo revisor.

Os demais módulos foram preservados no pacote de origem. Alterações compartilhadas de registro/rota estão limitadas à integração e diagnóstico de Visão; preserve acréscimos do grupo ao fazer merge. Os CSVs originais têm hashes idênticos, listados em csvs_originais_preservados.json. Nenhum áudio, vídeo antigo ou captura de outra versão foi declarado como evidência nova.

Foram excluídos do ZIP os caches compilados Python e caches de avaliação. O ZIP original foi mantido intacto. Não se atribui a falha local a esses caches sem evidência adicional.
