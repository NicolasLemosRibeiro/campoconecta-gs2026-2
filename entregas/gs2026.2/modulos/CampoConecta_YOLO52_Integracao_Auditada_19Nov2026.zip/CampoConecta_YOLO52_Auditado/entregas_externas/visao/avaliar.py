"""Escolhe confiança em validação e mede desempenho em teste reservado."""
import argparse
import csv
import json
import os
import platform
import statistics
import time
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("MKL_NUM_THREADS", "4")

import cv2
import torch
import ultralytics
from PIL import Image, ImageDraw, ImageFont
from ultralytics import YOLO

NMS_IOU = 0.60
IOU_MATCH = 0.50
LIMIARES = [i / 100 for i in range(5, 76, 5)]


def iou(a, b):
    sobreposicao = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    uniao = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - sobreposicao
    return sobreposicao / uniao if uniao else 0


def rotulos(pasta, split, caminho, largura, altura):
    arquivo = pasta / "labels" / split / (caminho.stem + ".txt")
    saida = []
    for linha in arquivo.read_text(encoding="utf-8").splitlines():
        _, x, y, w, h = map(float, linha.split())
        saida.append([(x-w/2)*largura, (y-h/2)*altura, (x+w/2)*largura, (y+h/2)*altura])
    return saida


def contar(amostra, limiar):
    alvos, preds = amostra["rotulos"], amostra["predicoes"]
    livres = set(range(len(alvos)))
    tp = fp = 0
    for confianca, caixa in preds:
        if confianca < limiar:
            continue
        melhor = max(livres, key=lambda j: iou(caixa, alvos[j]), default=None)
        if melhor is not None and iou(caixa, alvos[melhor]) >= IOU_MATCH:
            livres.remove(melhor)
            tp += 1
        else:
            fp += 1
    return tp, fp, len(livres)


def metricas(amostras, limiar):
    contagens = [contar(a, limiar) for a in amostras]
    tp, fp, fn = map(sum, zip(*contagens))
    precisao = tp / (tp+fp) if tp+fp else 0
    recall = tp / (tp+fn) if tp+fn else 0
    f1 = 2 * precisao * recall / (precisao+recall) if precisao+recall else 0
    return dict(limiar=limiar, imagens=len(amostras), tp=tp, fp=fp, fn=fn,
                precisao=precisao, recall=recall, f1=f1)


def inferir(modelo, pasta, split, tamanho, dispositivo):
    resultados = []
    for caminho in sorted((pasta / "images" / split).glob("*.jpg")):
        r = modelo.predict(
            str(caminho), imgsz=tamanho, conf=0.001, iou=NMS_IOU, max_det=50,
            device=dispositivo, verbose=False,
        )[0]
        altura, largura = r.orig_shape
        predicoes = sorted(zip(r.boxes.conf.tolist(), r.boxes.xyxy.tolist()), reverse=True)
        resultados.append({
            "arquivo": caminho, "rotulos": rotulos(pasta, split, caminho, largura, altura),
            "predicoes": predicoes,
        })
    return resultados


def _desenhar(amostra, limiar, destino):
    with Image.open(amostra["arquivo"]) as orig:
        imagem = orig.convert("RGB")
    desenho = ImageDraw.Draw(imagem)
    escala = max(1, round(imagem.width / 420))
    fonte = ImageFont.load_default(size=12 * escala)

    def marcar(caixa, cor, rotulo):
        x, y, _, _ = caixa
        desenho.rectangle(caixa, outline=cor, width=3*escala)
        x = min(x, max(0, imagem.width - desenho.textlength(rotulo, font=fonte) - 8))
        y = max(0, y - 19*escala)
        desenho.text((x+1, y), rotulo, font=fonte, fill=cor, stroke_width=2, stroke_fill="black")

    for caixa in amostra["rotulos"]:
        marcar(caixa, "#ffd34f", "Anotação D40")
    for confianca, caixa in amostra["predicoes"]:
        if confianca >= limiar:
            marcar(caixa, "#36f2b0", f"Modelo {confianca:.0%}")
    imagem.thumbnail((720, 720))
    imagem.save(destino, quality=91)


def medir_cpu(modelo, amostras, tamanho, limiar):
    caminhos = [str(a["arquivo"]) for a in amostras[:30]]
    kwargs = dict(imgsz=tamanho, conf=limiar, iou=NMS_IOU, max_det=50, device="cpu", verbose=False)
    for caminho in caminhos[:5]:
        modelo.predict(caminho, **kwargs)
    ms = []
    for caminho in caminhos:
        inicio = time.perf_counter()
        modelo.predict(caminho, **kwargs)
        ms.append((time.perf_counter() - inicio)*1000)
    media = statistics.mean(ms)
    return dict(imagens=len(ms), aquecimento=5, media_ms=media, fps=len(ms)/(sum(ms)/1000),
                threads_torch=torch.get_num_threads(), plataforma=platform.platform(),
                cpu=_cpu(), imgsz=tamanho, dispositivo="cpu")


def _cpu():
    proc = Path("/proc/cpuinfo")
    if proc.exists():
        for linha in proc.read_text().splitlines():
            if linha.startswith("model name"):
                return linha.split(":", 1)[1].strip()
    return platform.processor() or platform.machine()


def principal(dados, pesos, saida, dispositivo):
    torch.set_num_threads(min(4, torch.get_num_threads()))
    saida.mkdir(parents=True, exist_ok=True)
    config = json.loads((pesos.parent / "treino_config.json").read_text(encoding="utf-8"))
    tamanho = config["imgsz"]
    modelo = YOLO(str(pesos), task="detect")
    validacao = inferir(modelo, dados.parent, "val", tamanho, dispositivo)
    grade = [metricas(validacao, limiar) for limiar in LIMIARES]
    escolhido = max(grade, key=lambda v: (v["f1"], v["recall"], v["limiar"]))
    limiar = escolhido["limiar"]
    teste = inferir(modelo, dados.parent, "test", tamanho, dispositivo)
    teste_metricas = metricas(teste, limiar)
    import yaml
    descricao = yaml.safe_load(dados.read_text(encoding="utf-8"))
    descricao["path"] = str(dados.parent.resolve())
    yaml_execucao = saida / "dados_avaliacao.yaml"
    yaml_execucao.write_text(yaml.safe_dump(descricao, sort_keys=False), encoding="utf-8")
    ap = modelo.val(data=str(yaml_execucao.resolve()), split="test", imgsz=tamanho, conf=0.001,
                    iou=NMS_IOU, max_det=50, batch=12, device=dispositivo, workers=0,
                    project=str(saida.resolve()), name="metricas_ultralytics", plots=True, verbose=True)
    # Depois de val() reinicia o predictor para garantir medição em CPU, mesmo após treino em GPU.
    modelo.predictor = None
    desempenho = medir_cpu(modelo, teste, tamanho, limiar)
    resultado = dict(val=escolhido, teste=teste_metricas, ap50=ap.box.map50, map50_95=ap.box.map,
                     desempenho=desempenho, config=config,
                     versoes=dict(torch=str(torch.__version__), ultralytics=ultralytics.__version__, cv2=cv2.__version__))
    (saida / "metricas.json").write_text(json.dumps(resultado, indent=2), encoding="utf-8")
    (saida / "ajustes.json").write_text(json.dumps({
        "imgsz": tamanho, "conf": limiar, "nms_iou": NMS_IOU,
    }, indent=2), encoding="utf-8")
    with (saida / "limiares_validacao.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=grade[0].keys())
        writer.writeheader()
        writer.writerows(grade)
    exemplos = saida / "exemplos"
    exemplos.mkdir(exist_ok=True)
    casos = []
    for a in teste:
        tp, fp, fn = contar(a, limiar)
        casos.append({"arquivo": a["arquivo"].name, "tp": tp, "fp": fp, "fn": fn,
                      "maior_conf": max((c for c, _ in a["predicoes"] if c >= limiar), default=0)})
    with (saida / "casos_teste.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=casos[0].keys())
        writer.writeheader()
        writer.writerows(casos)
    grupos = {
        "acerto": sorted((i for i,c in enumerate(casos) if c["tp"] and not c["fp"] and not c["fn"]),
                         key=lambda i: -casos[i]["maior_conf"]),
        "falso_positivo": sorted((i for i,c in enumerate(casos) if c["fp"]),
                                 key=lambda i: -casos[i]["maior_conf"]),
        "falso_negativo": [i for i,c in enumerate(casos) if c["fn"] and not c["tp"]],
    }
    for nome, indices in grupos.items():
        for i in indices[:10]:
            _desenhar(teste[i], limiar, exemplos / f'{nome}_{casos[i]["arquivo"]}')
    print(json.dumps(resultado, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dados", type=Path, required=True)
    p.add_argument("--pesos", type=Path, required=True)
    p.add_argument("--saida", type=Path, default=Path("resultados_visao"))
    p.add_argument("--dispositivo", default="0" if torch.cuda.is_available() else "cpu")
    a = p.parse_args()
    principal(a.dados, a.pesos, a.saida, a.dispositivo)
