# Conferência do pacote de reinício

Conferência realizada em 19/11/2026, em Linux/Python 3.12, com NumPy 1.26.4, OpenCV 4.11.0, Ultralytics 8.4.215, pandas 2.2.3 e PyArrow 21.0.0. O código de produção do backend e do frontend foi preservado; foram ajustados os requisitos de instalação e acrescentado o iniciador.

- 35 testes do backend aprovados.
- Oito testes da interface aprovados.
- Iniciador abriu a API e o servidor Streamlit em portas livres.
- AppTest abriu as quatro abas contra a API real, sem exceções.
- API respondeu corretamente às imagens positiva e negativa e a um arquivo inválido; continuou disponível após a entrada inválida.
- A avaliação do checkpoint extraído do ZIP reproduziu exatamente as contagens de validação e teste e os valores AP@50 e mAP@50–95 registrados. O resumo padrão voltou a exibir 0,485 de precisão, ou 48,5% arredondado, no teste conhecido.
- O hash dos pesos ativos corresponde ao checkpoint original YOLO11s. Não houve novo treinamento.
- As dependências foram resolvidas para o alvo Apple Silicon/Python 3.12 em uma lista fixada. Essa resolução não é execução nativa no macOS; a abertura final no Mac deve ser confirmada pelo grupo.

A avaliação padrão original registrou precisão de 49,2% na validação e 48,5% no teste. A contagem operacional com limiar fixo é registrada separadamente. Tempos medidos aqui não representam o Mac.
