"""Seleciona e prepara a classe D40 do RDD2022 India usando rótulos Pascal VOC."""
import argparse
import csv
import hashlib
import io
import random
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

import cv2
import numpy as np
from PIL import Image

SEMENTE = 2026
CLASSE_VOC = "D40"
COTAS = {"train": (185, 115), "val": (48, 32), "test": (56, 44)}


def grupo_split(nome):
    origem, numero = Path(nome).stem.rsplit("_", 1)
    grupo = f"{origem}_{int(numero) // 35:04d}"
    faixa = int(hashlib.sha256(grupo.encode()).hexdigest()[:8], 16) % 100
    return grupo, ("train" if faixa < 70 else "val" if faixa < 85 else "test")


def phash(imagem):
    cinza = np.asarray(imagem.convert("L").resize((32, 32)), dtype=np.float32)
    coeficientes = cv2.dct(cinza)[:8, :8].reshape(-1)[1:]
    return int("".join("1" if x > np.median(coeficientes) else "0" for x in coeficientes), 2)


def voc_ler(conteudo):
    raiz = ET.fromstring(conteudo)
    objetos = []
    for objeto in raiz.findall("object"):
        classe = (objeto.findtext("name") or "").strip()
        box = objeto.find("bndbox")
        if box is None:
            continue
        caixa = tuple(float(box.findtext(c)) for c in ("xmin", "ymin", "xmax", "ymax"))
        objetos.append((classe, caixa))
    return objetos


def normalizar(caixas, w, h):
    linhas = []
    for x1, y1, x2, y2 in caixas:
        x1, x2 = max(0, x1), min(w, x2)
        y1, y2 = max(0, y1), min(h, y2)
        if x2 > x1 and y2 > y1:
            centro = ((x1+x2)/(2*w), (y1+y2)/(2*h), (x2-x1)/w, (y2-y1)/h)
            linhas.append("0 " + " ".join(f"{v:.8f}" for v in centro))
    return linhas


def indexar(arquivo):
    nomes = arquivo.namelist()
    imagens = {
        PurePosixPath(n).stem: n for n in nomes
        if "/train/images/" in "/" + n and n.lower().endswith((".jpg", ".jpeg"))
    }
    rotulos = {
        PurePosixPath(n).stem: n for n in nomes
        if "/train/annotations/" in "/" + n and n.lower().endswith(".xml")
    }
    assert imagens and rotulos, "O ZIP deve conter train/images e train/annotations do RDD2022."
    entradas = []
    distribuicao = Counter()
    for stem in sorted(imagens.keys() & rotulos.keys()):
        objetos = voc_ler(arquivo.read(rotulos[stem]))
        distribuicao.update(c for c, _ in objetos)
        caixas = [box for classe, box in objetos if classe == CLASSE_VOC]
        grupo, split = grupo_split(stem)
        entradas.append((stem, imagens[stem], rotulos[stem], grupo, split, caixas))
    print("Anotações na origem:", dict(sorted(distribuicao.items())), flush=True)
    return entradas


def escrever_yaml(destino):
    (destino / "dados.yaml").write_text(
        f"path: {destino.resolve()}\ntrain: images/train\nval: images/val\n"
        "test: images/test\nnames:\n  0: buraco\n", encoding="utf-8",
    )


def principal(origem, destino):
    rng = random.Random(SEMENTE)
    hashes, chaves, escolhidas = {}, set(), []
    with ZipFile(origem) as arquivo:
        entradas = indexar(arquivo)
        rng.shuffle(entradas)
        for split, (positivos, negativos) in COTAS.items():
            for tem_dano, quantidade in ((True, positivos), (False, negativos)):
                n = 0
                for stem, caminho, xml, grupo, conjunto, caixas in entradas:
                    if conjunto != split or bool(caixas) != tem_dano:
                        continue
                    conteudo = arquivo.read(caminho)
                    sha = hashlib.sha256(conteudo).hexdigest()
                    if sha in chaves:
                        continue
                    with Image.open(io.BytesIO(conteudo)) as im:
                        im.load()
                        w, h = im.size
                        assinatura = phash(im)
                    if any((assinatura ^ anterior).bit_count() <= 4 and s != split
                           for anterior, s in hashes.items()):
                        continue
                    linhas = normalizar(caixas, w, h)
                    if caixas and not linhas:
                        continue
                    hashes[assinatura] = split
                    chaves.add(sha)
                    imagem = destino / "images" / split / f"{stem}.jpg"
                    rotulo = destino / "labels" / split / f"{stem}.txt"
                    imagem.parent.mkdir(parents=True, exist_ok=True)
                    rotulo.parent.mkdir(parents=True, exist_ok=True)
                    imagem.write_bytes(conteudo)
                    rotulo.write_text("\n".join(linhas) + ("\n" if linhas else ""), encoding="utf-8")
                    escolhidas.append(dict(imagem=imagem.name, grupo=grupo, split=split,
                                            largura=w, altura=h, caixas_d40=len(linhas), sha256=sha,
                                            phash=f"{assinatura:016x}", xml_original=xml))
                    n += 1
                    if n == quantidade:
                        break
                if n != quantidade:
                    raise ValueError(f"{split}: apenas {n}/{quantidade} imagens da cota.")
                print(f"{split:5} D40={str(tem_dano):5} {n}/{quantidade}", flush=True)
    with (destino / "manifesto.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=escolhidas[0].keys())
        writer.writeheader()
        writer.writerows(escolhidas)
    escrever_yaml(destino)
    print(f"{len(escolhidas)} imagens prontas em {destino.resolve()}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--origem", type=Path, required=True)
    parser.add_argument("--destino", type=Path, default=Path("dados_rdd2022"))
    args = parser.parse_args()
    principal(args.origem, args.destino)
