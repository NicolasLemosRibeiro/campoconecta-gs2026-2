# CampoConecta — Visão Computacional

YOLO11s para detectar possíveis buracos D40 e apoiar a seleção de locais para vistoria. O checkpoint foi treinado no Colab; sua avaliação foi repetida em CPU. O relatório e o notebook distinguem as métricas do resumo Ultralytics das contagens no limiar fixado para a API. A equipe responsável avalia gravidade e intervenção.

## Aplicação

Com Python3.12, na raiz CampoConecta:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/requirements.txt -r frontend/requirements.txt -r entregas_externas/visao/requirements-visao.txt
cd backend
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Em outro terminal, a partir da raiz:

```bash
source .venv/bin/activate
cd frontend
python -m streamlit run app.py --server.address 127.0.0.1
```

Use a aba Módulos > Análise de pavimentação. Para integrar ao trabalho do grupo, consulte INTEGRACAO_GOVERNANCA.md. Copie pesos e ajustes juntos e reinicie a API.

## Reprodução

O notebook verifica a amostra, o hash dos pesos e repete a avaliação. REPETIR_TREINO permanece False para conferir o checkpoint entregue. O script treinar.py permite novo treino com o protocolo registrado; os resultados podem variar. Não há chave de API. A inferência usa recursos locais; a instalação inicial e o download de pesos COCO para novo treino precisam de internet.

A amostra mantém300 imagens de treino,80 de validação e100 de teste. Não foram movidas imagens entre conjuntos. O teste é conhecido e já havia sido examinado; não demonstra generalização independente em vias brasileiras.

O vídeo não está incluído nesta versão. Será enviado separadamente. As evidências anteriores foram preservadas como históricas; não representam o checkpoint atual.

## Fontes

RDD2022 — Arya et al.: https://arxiv.org/abs/2209.08538 . Imagens e adaptações sob CC BY-SA4.0 conforme o pacote de origem. YOLO11: https://docs.ultralytics.com/models/yolo11/ .
