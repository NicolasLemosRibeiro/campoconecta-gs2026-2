# Computação Quântica

A entrega completa está no pacote separado GS_Quantica_CampoConecta, incluído junto dos demais trabalhos na revisão consolidada. O estudo compara agendamento clássico e apresenta um roadmap quântico condicional. Não houve execução quântica.
