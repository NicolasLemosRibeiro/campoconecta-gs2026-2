"""Upload, envio e renderização no AppTest com API e detector reais."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'frontend'))
from streamlit.testing.v1 import AppTest

def main():
    resultados=[]
    for nome,positivo in [('India_008389.jpg',True),('India_000145.jpg',False)]:
        foto=ROOT/'entregas_externas/visao/demonstracao/imagens'/nome
        at=AppTest.from_file(str(ROOT/'frontend/app.py'),default_timeout=90).run()
        assert not at.exception,str(at.exception)
        at.file_uploader[0].set_value((nome,foto.read_bytes(),'image/jpeg'))
        botao=next(b for b in at.button if b.label=='Analisar imagem')
        botao.click().run(timeout=90)
        assert not at.exception,str(at.exception)
        assert not at.error and not at.warning, str(at.warning)
        assert len(at.image)==1,'Imagem anotada não apareceu na tela'
        tabelas=[t for t in at.table if 'Dano' in t.value.columns]
        if positivo:
            assert len(tabelas)==1 and len(tabelas[0].value)>0
            assert tabelas[0].value.iloc[0]['Dano']=='Buraco na pavimentação'
        else:
            assert len(tabelas)==0
        resultados.append({'arquivo':nome,'upload_formulario_real':True,'imagem_renderizada':True,'tabela_com_caixas':positivo,'sem_excecoes':True})
    print(json.dumps({'tela_visao_api_real':resultados,'limite':'Interação automatizada pelo AppTest do Streamlit, sem navegador físico ou execução nativa no macOS.'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
