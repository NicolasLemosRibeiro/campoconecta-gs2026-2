"""Inicialização local e conferência do pacote CampoConecta."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

RAIZ = Path(__file__).resolve().parent

def conferir():
    manifesto = json.loads((RAIZ / 'integridade.json').read_text(encoding='utf-8'))
    for nome, esperado in manifesto['sha256'].items():
        arquivo = RAIZ / nome
        if not arquivo.is_file() or hashlib.sha256(arquivo.read_bytes()).hexdigest() != esperado:
            raise RuntimeError(f'Arquivo incompleto ou alterado: {nome}. Extraia novamente o ZIP em uma pasta nova.')
    print(f"Integridade conferida: {len(manifesto['sha256'])} arquivos; pesos YOLO11s originais.", flush=True)

def preparar():
    if sys.version_info[:2] != (3, 12):
        raise RuntimeError('Use Python 3.12. O iniciador iniciar_mac.command seleciona essa versão.')
    ambiente = RAIZ / '.venv_mac'
    python = ambiente / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.is_file():
        subprocess.run([sys.executable, '-m', 'venv', str(ambiente)], check=True)
    requisitos = [RAIZ / p for p in ('backend/requirements.txt', 'frontend/requirements.txt', 'entregas_externas/visao/requirements-visao.txt')]
    if sys.platform == 'darwin':
        requisitos = [RAIZ / 'requirements-mac.lock.txt']
    assinatura = hashlib.sha256(b''.join(p.read_bytes() for p in requisitos)).hexdigest()
    marca = ambiente / 'dependencias_ok.json'
    if not marca.is_file() or json.loads(marca.read_text()).get('sha256') != assinatura:
        print('Instalando as dependências na primeira abertura. Aguarde...', flush=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)
        comando = [str(python), '-m', 'pip', 'install']
        for p in requisitos:
            comando += ['-r', str(p)]
        subprocess.run(comando, check=True)
        subprocess.run([str(python), '-m', 'pip', 'check'], check=True)
        marca.write_text(json.dumps({'sha256': assinatura}), encoding='utf-8')
    return python

def porta_livre():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def aguardar(url, processo):
    limite = time.monotonic() + 90
    while time.monotonic() < limite:
        if processo.poll() is not None:
            raise RuntimeError(f'Um serviço encerrou na inicialização. Consulte os arquivos em logs/inicializacao/.')
        try:
            with urllib.request.urlopen(url, timeout=2) as resposta:
                if resposta.status == 200:
                    return
        except (urllib.error.URLError, TimeoutError, OSError):
            time.sleep(0.25)
    raise RuntimeError(f'O serviço não iniciou a tempo: {url}. Consulte logs/inicializacao/.')

def postagem(url, nome, conteudo):
    fronteira = 'CampoConectaTesteLocal'
    corpo = (f'--{fronteira}\r\nContent-Disposition: form-data; name="imagem"; filename="{nome}"\r\nContent-Type: image/jpeg\r\n\r\n').encode() + conteudo + f'\r\n--{fronteira}--\r\n'.encode()
    pedido = urllib.request.Request(url, data=corpo, headers={'Content-Type': f'multipart/form-data; boundary={fronteira}'})
    with urllib.request.urlopen(pedido, timeout=90) as resposta:
        return json.load(resposta)

def executar(python, teste=False, abrir=True):
    logs = RAIZ / 'logs/inicializacao'
    logs.mkdir(parents=True, exist_ok=True)
    api_porta = porta_livre()
    web_porta = porta_livre()
    while web_porta == api_porta:
        web_porta = porta_livre()
    api = f'http://127.0.0.1:{api_porta}'
    pagina = f'http://127.0.0.1:{web_porta}'
    env = os.environ.copy()
    env.update({'CAMPOCONECTA_VISAO_PESOS': str(RAIZ / 'backend/app/modulos/pesos_visao/best.pt'), 'CAMPOCONECTA_VISAO_AJUSTES': str(RAIZ / 'backend/app/modulos/pesos_visao/ajustes.json'), 'API_URL': api, 'CORS_ORIGINS': pagina, 'YOLO_AUTOINSTALL': 'false', 'STREAMLIT_BROWSER_GATHER_USAGE_STATS': 'false'})
    subprocess.run([str(python), str(RAIZ / 'diagnosticar_visao.py'), '--saida',
                    str(logs / 'diagnostico_visao.json')], cwd=RAIZ, env=env, check=True)
    processos = []
    arquivos = []
    try:
        comandos = [
            ('backend', [str(python), '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', str(api_porta)]),
            ('frontend', [str(python), '-m', 'streamlit', 'run', 'app.py', '--server.address', '127.0.0.1', '--server.port', str(web_porta), '--server.headless', 'true', '--browser.gatherUsageStats', 'false', '--global.developmentMode', 'false']),
        ]
        for pasta, comando in comandos:
            log = (logs / f'{pasta}.log').open('wb')
            arquivos.append(log)
            processos.append(subprocess.Popen(comando, cwd=RAIZ / pasta, env=env, stdout=log, stderr=subprocess.STDOUT))
        aguardar(api + '/health', processos[0])
        aguardar(pagina + '/_stcore/health', processos[1])
        print(f'Sistema pronto: {pagina}\nAPI desta execução: {api}\nPara encerrar, pressione Control+C neste terminal.', flush=True)
        if teste:
            codigo_tela = "from streamlit.testing.v1 import AppTest; at = AppTest.from_file('app.py', default_timeout=30).run(); assert not at.exception, str(at.exception); assert len(at.tabs) == 4; print('Interface com API real: quatro abas, sem exceções.')"
            with (logs / 'interface_teste.log').open('w') as log_tela:
                subprocess.run([str(python), '-c', codigo_tela], cwd=RAIZ / 'frontend', env=env, stdout=log_tela, stderr=subprocess.STDOUT, check=True)
            with (logs / 'tela_visao_real.log').open('w') as log_visao:
                subprocess.run([str(python), str(RAIZ / 'validar_tela_visao.py')], cwd=RAIZ / 'frontend',
                               env=env, stdout=log_visao, stderr=subprocess.STDOUT, check=True)
            fotos = RAIZ / 'entregas_externas/visao/demonstracao/imagens' 
            positivo = postagem(api + '/modulos/visao/analisar', 'India_008389.jpg', (fotos / 'India_008389.jpg').read_bytes())
            negativo = postagem(api + '/modulos/visao/analisar', 'India_000145.jpg', (fotos / 'India_000145.jpg').read_bytes())
            invalido = postagem(api + '/modulos/visao/analisar', 'invalido.jpg', b'arquivo de teste')
            assert positivo['disponivel'] and positivo['caixas'] and positivo['confianca'] > 0
            assert negativo['disponivel'] and not negativo['caixas']
            assert not invalido['disponivel'] and 'ler a imagem' in invalido['mensagem']
            subprocess.run([str(python), str(RAIZ / 'entregas_externas/visao/sequencia_api.py'),
                '--api', api, '--imagens', str(fotos), '--saida', str(logs / 'sequencia')], cwd=RAIZ, env=env, check=True)
            aguardar(api + '/health', processos[0])
            resultado = {'status': 'aprovado', 'positivo': positivo, 'negativo': negativo, 'invalido': invalido, 'frontend_http': 200, 'interface_api_real': 'quatro abas sem exceções'}
            (logs / 'teste_integracao.json').write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding='utf-8')
            print('Teste real de API, imagem positiva, negativa, inválida e servidor da interface: APROVADO.', flush=True)
            return
        if abrir:
            webbrowser.open(pagina)
        while all(p.poll() is None for p in processos):
            time.sleep(0.5)
        raise RuntimeError('Um serviço encerrou. Consulte logs/inicializacao/.')
    except KeyboardInterrupt:
        print('\nEncerrando os dois serviços...', flush=True)
    finally:
        for p in processos:
            if p.poll() is None:
                p.terminate()
        for p in processos:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait()
        for f in arquivos:
            f.close()

def main():
    parser = argparse.ArgumentParser(description='Abrir e conferir o CampoConecta local.')
    parser.add_argument('--verificar', action='store_true', help='Conferir os arquivos sem instalar ou iniciar serviços.')
    parser.add_argument('--teste', action='store_true', help='Verificar a inicialização e testar três entradas na API.')
    parser.add_argument('--python-atual', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    conferir()
    if args.verificar:
        return
    python = Path(sys.executable) if args.python_atual else preparar()
    executar(python, teste=args.teste, abrir=not args.teste)

if __name__ == '__main__':
    try:
        main()
    except Exception as erro:
        print(f'\nNão foi possível concluir: {erro}', file=sys.stderr, flush=True)
        sys.exit(1)
