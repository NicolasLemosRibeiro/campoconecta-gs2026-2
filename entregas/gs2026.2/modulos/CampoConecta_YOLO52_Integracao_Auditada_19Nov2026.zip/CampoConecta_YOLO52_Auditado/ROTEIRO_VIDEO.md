# Roteiro de Visão — versão correspondente à Execução Final

1. Apresentar Pedro Leal Murad, Murilo Benhossi e Nicolas Lemos Ribeiro e o objetivo de triagem de buracos para apoiar a vistoria humana.
2. Mostrar a divisão de 480 imagens do RDD2022: 300 de treino, 80 de validação e 100 de teste conhecido; anotações D40 convertidas para YOLO.
3. Mostrar o YOLO11s com entrada de 640 pixels, pesos COCO, 64 épocas executadas de até 80 e checkpoint da época 46. Não executar novo treino durante a apresentação.
4. Mostrar a avaliação padrão do Colab: precisão de 49,2% na validação e 48,5% no teste; recall de 36,0% no teste, AP@50 de 38,3% e mAP@50–95 de 12,3%. A precisão melhorou, mas o recall caiu frente ao resumo anterior.
5. Explicar separadamente o ponto operacional da API: confiança mínima 0,25 e NMS IoU 0,60. Nessa contagem, a precisão no teste é 52,2%, com recall de 32,7% e F1 de 40,2%; é outro procedimento de medição, não um novo ganho de treinamento.
6. Mostrar a imagem positiva e a negativa processadas pela API com os pesos atuais, além de um acerto, um falso positivo e um falso negativo do teste.
7. Concluir com limites: amostra pequena, teste já conhecido, possibilidade de erros e necessidade de revisão humana. Os experimentos posteriores não justificaram substituir os pesos escolhidos.

Atualize as capturas e as falas numéricas do vídeo anterior. O tempo medido em CPU Linux e o registro histórico da GPU T4 são medições distintas e não representam o Mac.
