# Conferência técnica — Execução Final, 19/11/2026

Foram aprovados 35 testes do backend e executadas em ordem as oito células de código do notebook de Visão. A API foi verificada por HTTP com exemplos positivo e negativo e uma sequência de 12 imagens. A repetição local reproduziu as contagens de validação e teste e os valores AP@50 e mAP@50–95 do checkpoint entregue.

Os pesos escolhidos são YOLO11s, entrada de 640 pixels. O código de produção e o contrato da API foram preservados. Foi explicitada a dependência pi-heif usada pelo leitor de imagens do Ultralytics 8.4.215, inclusive para rejeitar entradas inválidas. Instale também entregas_externas/visao/requirements-visao.txt.

Evidências atuais: entregas_externas/visao/conferencia_execucao_final/. Resultados anteriores: entregas_externas/visao/historico/. O teste conhecido já havia sido consultado; estes resultados não constituem avaliação independente em novas vias.

O vídeo é fornecido separadamente. Não use capturas do modelo anterior para representar estes pesos.
