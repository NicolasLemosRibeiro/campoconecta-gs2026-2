# Entrega técnica — YOLO52 auditado

Comece pelo README. O pacote contém o detector original, os dados e a documentação, com correções restritas à integração de Visão. Não houve substituição de pesos. Foram executados testes reais da API e do formulário Streamlit, uma sequência de 12 imagens e reavaliação das 80 imagens de validação e 100 de teste conhecido. Os detalhes estão em entregas_externas/visao/auditoria_integracao_1911/.

Os CSVs originais foram preservados. Os outros módulos mantêm seus arquivos originais nesta cópia de origem; os acréscimos feitos pelo grupo em outro projeto devem ser preservados no merge. O vídeo não está incluído. A execução nativa no Mac e a identificação da falha específica desse ambiente ainda dependem da conferência local documentada no README.
