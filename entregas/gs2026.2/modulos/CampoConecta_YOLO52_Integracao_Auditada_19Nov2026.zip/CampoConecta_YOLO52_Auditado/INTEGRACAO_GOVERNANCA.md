# Integração da Visão no CampoConecta do grupo

Origem desta revisão: GS_Visao_CampoConecta_Mac_Execucao_Final.zip. O YOLO11s, os pesos e os parâmetros operacionais foram preservados. Precisão operacional de teste: 52,24%, com limiar 0,25. Não houve novo treinamento.

## Projeto que já contém outros módulos integrados

Preserve o projeto atual e faça uma cópia de segurança. Não substitua o backend ou o frontend inteiro por este pacote.

1. Confira se `backend/app/modulos/pesos_visao/best.pt` tem SHA-256 `2e0464c17a6f76349e03389d0e0739623945ef4c81ffcf4ba84c1ae4d072ba62`. Os ajustes correspondentes são `imgsz=640`, `conf=0.25`, `nms_iou=0.6`. Não substitua pesos diferentes sem decidir antes qual versão será usada.
2. Atualize `backend/app/modulos/impl_visao.py` com a implementação conferida deste pacote. Ela verifica a identidade dos pesos e dos ajustes antes de carregar o detector.
3. Em `backend/app/modulos/registro.py`, integre a classe `ErroIntegracaoVisao` e a função `carregar` revisada. Em `status`, capture essa exceção como na versão conferida. **Preserve todos os slots e alterações que o grupo acrescentou.** O comportamento dos módulos opcionais foi mantido.
4. Em `backend/app/routers/modulos.py`, integre somente o tratamento de carregamento e execução da rota de Visão, com o logger correspondente. Preserve as demais rotas. O contrato e o formato JSON não mudaram.
5. Copie `diagnosticar_visao.py` para a raiz. Na raiz do projeto, execute `.venv/bin/python diagnosticar_visao.py` usando o mesmo ambiente da API. O diagnóstico precisa terminar com `YOLO CARREGADO E INFERÊNCIA REAL APROVADA`.
6. Reinicie a API; um processo antigo pode continuar usando módulos já importados antes da correção. No terminal do backend, use `../.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000`. O Streamlit deve usar `API_URL=http://127.0.0.1:8000` e pode permanecer na porta 8501.
7. Confira as imagens positiva e negativa indicadas no README na própria tela **Módulos → Análise de pavimentação**. Verifique caixa, classe, confiança e latência.

Não é necessário refazer treinamento. NumPy 1.26.4, OpenCV 4.11.0.86, Ultralytics 8.4.215 e PyArrow 17.0.0 correspondem às versões informadas pelo usuário; se o ambiente atual já passou em `pip check`, preserve-o para a conferência. O instalador para uma pasta nova usa `requirements-mac.lock.txt`.

## Evidências e documentação

Acompanham o notebook, PDF e resultados originais, além de `entregas_externas/visao/auditoria_integracao_1911/`. Use as métricas com identificação do método. A sequência de 12 imagens é uma demonstração do endpoint, não um vídeo de câmera ao vivo e não uma medição independente de precisão.

Os CSVs originais não foram alterados. PLN e Quântica são entregas separadas. A gravação final de apresentação será encaminhada depois, com áudio e capturas correspondentes aos pesos vigentes.
