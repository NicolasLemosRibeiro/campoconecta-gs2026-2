# Atualização da Visão — 19/11/2026

Esta revisão preserva os pesos YOLO11s e o ponto operacional 640/0,25/0,60 do pacote original. Corrige a ocultação de falhas no carregador e acrescenta um diagnóstico com inferência real antes da inicialização pelo iniciador. As alterações de integração estão discriminadas em INTEGRACAO_GOVERNANCA.md; preserve os slots e rotas adicionais do grupo ao fazer o merge.

As contagens reproduzidas no teste são TP=35, FP=32 e FN=72, com precisão de 52,24%, recall de 32,71% e F1 de 40,23%. Os 48,45% do resumo padrão do Ultralytics correspondem a outro ponto da curva. O limiar da API permanece 0,25.

A revisão não identificou uma falha de importação no ZIP original neste ambiente. O erro específico no Mac permanece sem causa comprovada até execução do diagnóstico local. Não confundir essa limitação com os testes funcionais aprovados no ambiente de conferência.
