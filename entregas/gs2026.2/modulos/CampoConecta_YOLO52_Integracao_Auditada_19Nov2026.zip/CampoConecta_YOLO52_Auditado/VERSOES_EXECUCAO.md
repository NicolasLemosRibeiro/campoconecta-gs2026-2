# Versões e resultados

Versão vigente: YOLO11s, 640 pixels, checkpoint best.pt entregue junto de ajustes.json. Resumo padrão Colab: validação 49,2% de precisão; teste 48,5%. O relatório distingue esse resumo da contagem operacional com limiar fixo. As continuações em 640 e 832 pixels foram descartadas; não houve alcance da meta de 60% sem perda de recall.

Resultados e notebook vigentes estão em entregas_externas/visao/. O diretório historico/ contém versões anteriores, preservadas apenas para rastreabilidade. Não misture métricas, imagens ou pesos entre versões.
