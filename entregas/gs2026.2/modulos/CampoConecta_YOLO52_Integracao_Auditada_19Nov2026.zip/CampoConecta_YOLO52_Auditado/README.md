# CampoConecta — Visão Computacional auditada

FIAP · Global Solution 2026.2 · CitizenTech · 19/11/2026

| Integrante | RM |
|---|---|
| Pedro Leal Murad | 565460 |
| Murilo Benhossi | 562358 |
| Nicolas Lemos Ribeiro | 553273 |

O YOLO11s sinaliza possíveis buracos D40 em fotografias da via. As caixas apoiam a triagem para vistoria; confiança não mede gravidade nem garante segurança da via.

## Executar no macOS

Mac Apple Silicon, macOS 13 ou superior e Python 3.12. Internet apenas na primeira instalação. A Visão roda localmente em CPU, sem chave de API e sem novo treinamento.

1. Extraia o ZIP em **uma pasta nova dentro de Downloads**. Não mescle com pastas anteriores.
2. No Cursor, abra a pasta **CampoConecta_YOLO52_Auditado**, que contém este README.
3. No terminal dessa pasta, execute:

```bash
bash iniciar_mac.command
```

A primeira execução cria `.venv_mac` e instala as dependências fixadas. O iniciador confere os arquivos, carrega o YOLO e faz uma inferência real antes de mostrar **Sistema pronto**. API e Streamlit usam portas livres e o endereço correto é aberto no navegador. Mantenha o terminal aberto; **Control+C** encerra os dois serviços.

Na página, abra **Módulos → Análise de pavimentação**. Envie `entregas_externas/visao/demonstracao/imagens/India_008389.jpg`: o modelo deve mostrar uma caixa. `India_000145.jpg`, na mesma pasta, é o exemplo sem detecção.

## Conferir a execução

```bash
bash iniciar_mac.command --teste
```

O teste inicia os dois servidores, envia imagens reais pelo formulário automatizado do Streamlit, confere a API com entradas positiva, negativa e inválida e processa uma sequência de 12 imagens. Os registros ficam em `logs/inicializacao/`. Ao terminar, os servidores de teste são encerrados.

**Se o grupo já tem `.venv` instalado na raiz**, pode conferir esse ambiente sem instalar outro:

```bash
.venv/bin/python iniciar.py --teste --python-atual
```

Para revelar um erro local de importação ou carregamento usando esse mesmo ambiente:

```bash
.venv/bin/python diagnosticar_visao.py
```

O diagnóstico mostra o Python utilizado, o arquivo importado, o hash dos pesos e o resultado real. Falhas exibem a exceção original. Em uma instalação nova criada pelo iniciador, o ambiente correspondente é `.venv_mac`.

## Pesos e métricas

Preservado o `best.pt` do ZIP de origem `GS_Visao_CampoConecta_Mac_Execucao_Final.zip`. Entrada 640 px, confiança mínima 0,25, NMS IoU 0,60; até 50 caixas. SHA-256:

```text
2e0464c17a6f76349e03389d0e0739623945ef4c81ffcf4ba84c1ae4d072ba62
```

| Contagem operacional com limiar 0,25 | Validação: 80 imagens | Teste conhecido: 100 imagens |
|---|---:|---:|
| Precisão | 51,72% | **52,24%** |
| Recall | 32,26% | 32,71% |
| F1 | 39,74% | 40,23% |
| TP / FP / FN | 30 / 28 / 63 | 35 / 32 / 72 |

Esses valores foram reproduzidos com os mesmos pesos. No resumo padrão do Ultralytics, calculado em outro ponto da curva, a precisão registrada é 49,21% na validação e 48,45% no teste; AP@50 no teste é 38,31% e mAP@50–95, 12,30%. Não se trata de outro modelo. A confiança de uma caixa individual também é uma medida diferente.

A base contém 300 imagens de treino, 80 de validação e 100 de teste, do RDD2022/Índia. O teste já era conhecido; os resultados não demonstram generalização independente para novas vias.

## Entrega e integração

Notebook executado, relatório PDF, dados, métricas e exemplos estão em `entregas_externas/visao/`. Os testes desta revisão estão em `entregas_externas/visao/auditoria_integracao_1911/`. O vídeo será encaminhado separadamente.

O contrato continua `POST /modulos/visao/analisar`, formulário multipart com campo `imagem`, resposta `VisaoSaida`. Para integrar no projeto já alterado pelo grupo, siga **INTEGRACAO_GOVERNANCA.md**, preservando seus demais módulos.

**Limite da conferência:** testes executados em Linux/Python 3.12 com NumPy 1.26.4, OpenCV 4.11.0.86, Ultralytics 8.4.215 e PyArrow 17.0.0. Não houve execução nativa neste Mac M1. A instalação inicial no macOS ainda precisa da conferência local. A falha específica de importação relatada no Mac não foi reproduzida no ZIP original; o diagnóstico incluído revela sua causa caso persista.
