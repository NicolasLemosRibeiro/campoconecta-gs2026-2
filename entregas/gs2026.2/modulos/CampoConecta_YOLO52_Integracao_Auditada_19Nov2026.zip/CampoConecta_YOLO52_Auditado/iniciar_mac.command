#!/bin/bash
set -e
cd -- "$(dirname -- "$0")"
PYTHON_CAMPO=""
for candidato in /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 python3.12; do
    if command -v "$candidato" >/dev/null 2>&1; then
        PYTHON_CAMPO="$candidato"
        break
    fi
done
if [ -z "$PYTHON_CAMPO" ]; then
    echo "Python 3.12 não foi encontrado. Instale essa versão e tente novamente."
    read -r -p "Pressione Enter para fechar."
    exit 1
fi
if "$PYTHON_CAMPO" iniciar.py "$@"; then
    exit 0
else
    echo "Consulte a mensagem acima e os arquivos em logs/inicializacao."
    read -r -p "Pressione Enter para fechar."
    exit 1
fi
