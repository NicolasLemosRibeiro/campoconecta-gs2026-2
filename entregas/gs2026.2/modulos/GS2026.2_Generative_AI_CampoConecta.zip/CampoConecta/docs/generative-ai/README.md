# CampoConecta · Assistente de Defesa Civil

**Generative AI & Advanced Nets · FIAP · 2TIAPF · Global Solution 2026.2**

Pedro Leal Murad (RM565460), Murilo Benhossi (RM562358) e Nicolas Lemos Ribeiro (RM553273).

O CampoConecta tem uma aba de relatos para assistência rural e outra de **Chuvas e enchentes**. Na segunda, moradores e pequenos produtores podem perguntar como se preparar para uma chuva forte, o que fazer durante um alagamento ou quando voltar para casa. O chat mostra a publicação da Defesa Civil que embasa cada orientação e tem um botão para limpar a conversa. O assistente usa a rota `POST /modulos/assistente/perguntar` e aparece em `GET /modulos`.

- [Relatório de avaliação](relatorio.pdf)
- [Vídeo demonstrativo](../videos/generative-ai.mp4)
- [Registro por pergunta e configuração](evidencias/avaliacao.json)
- [Comparação de prompts e modelos](evidencias/experimentos.json)
- [Corpus curado](../../backend/app/modulos/defesa_civil/corpus.json)
- [Perguntas de desenvolvimento](../../data/assistente_casos.json) e [perguntas de verificação adicional](../../data/assistente_verificacao.json)

## Resultados da execução

O BM25 com seções recuperou a evidência completa em **18 de 18** consultas respondíveis no top-2. O Qwen2.5-1.5B acertou **10 de 20** escolhas com contexto controlado. No fluxo integrado, acertou **30 de 30** perguntas de desenvolvimento e **12 de 12** perguntas de verificação adicional. As **25 orientações emitidas** correspondiam ao texto de uma fonte oficial curada e ao gabarito da pergunta.

Sem o modelo, a busca e os filtros também resolveram os 42 casos. O Qwen2.5-7B acertou 18 de 20 escolhas no teste isolado. No chat integrado, acertou 39 de 42 e deixou de responder a três perguntas que a base cobria. O protótipo usa o 1,5B porque ele acertou mais no fluxo completo e respondeu mais rápido. Os dois conjuntos foram montados para o trabalho, sem validação com usuários.

## Executar localmente

Use Python 3.12 ou 3.13. O exemplo abaixo usa PowerShell a partir da raiz do repositório.

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r backend/requirements.txt -r frontend/requirements.txt
```

**Terminal 1 · inferência local no Windows x64**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\docs\generative-ai\rodar-modelo-windows.ps1
```

O script baixa o pacote CPU do llama.cpp b6000 e os pesos GGUF, confere SHA-256 e inicia o servidor no loopback. Aguarde a mensagem de serviço pronto ou consulte `http://127.0.0.1:8088/health`. Em Linux ou macOS, obtenha o [llama.cpp b6000](https://github.com/ggml-org/llama.cpp/releases/tag/b6000) para seu sistema e o GGUF indicado no script. Use `llama-server --model CAMINHO_DO_GGUF --host 127.0.0.1 --port 8088 --ctx-size 2048 --threads 6 --parallel 1`.

**Terminal 2 · API**

```powershell
$env:ASSISTENTE_LLM_URL = 'http://127.0.0.1:8088/v1/chat/completions'
Set-Location backend
..\.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

**Terminal 3 · interface**

```powershell
$env:API_URL = 'http://127.0.0.1:8000'
Set-Location frontend
..\.venv\Scripts\python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
```

Abra `http://127.0.0.1:8501` e selecione **Chuvas e enchentes**. Pergunte “Posso passar de carro por uma rua alagada?” e, em seguida, “E a pé?”. O texto sob a resposta identifica a origem da seleção. Na ausência do LLM, a aplicação oferece um modo extrativo com limiar de relevância e recusa em caso de empate próximo. Para iniciá-la em modo extrativo, omita `ASSISTENTE_LLM_URL` e o Terminal 1. A configuração padrão do Compose também usa o modo extrativo.

## Arquitetura e evidência

1. A base resume seis publicações da Defesa Civil e do Gov.br consultadas em 19/11/2026. Cada uma das 12 seções cobre uma dúvida e guarda ID, título, termos de busca, publicação, URL e data de consulta. O índice é montado em memória a partir do JSON, com um chunk por seção e sem sobreposição. A comparação inclui janelas de 48 e 72 palavras, com sobreposição de 12 e 18 palavras.
2. A busca usa BM25 com `k1=1,5`, `b=0,75` e `top-k=2`. Ela normaliza acentos e variantes, remove palavras muito comuns e usa termos acrescentados à base. Um trecho entra como candidato quando tem pontuação de pelo menos 1,6 e compartilha um termo específico com a pergunta. No modo extrativo, o primeiro trecho precisa de pelo menos 2,8 pontos e 0,4 de vantagem sobre o segundo. Os testes comparam k=1, 2 e 3 e incluem a contagem simples de termos em comum. A busca é lexical, sem embeddings.
3. O modelo devolve o número do trecho escolhido ou zero para se abster. O servidor só aceita um número inteiro válido, exibe o texto da base e monta a citação a partir dos metadados locais. A configuração usa temperatura 0, seed 42 e limite de 40 tokens. [Prompt e parâmetros](../../backend/app/modulos/defesa_civil/generator.py).
4. A conversa fica na sessão da interface até o usuário limpar o histórico. A API não guarda a conversa e só usa a pergunta anterior para seguimentos curtos sobre travessia. Expressões regulares mascaram dados reconhecidos antes da busca, da inferência e da devolução da pergunta. Erros de validação não repetem o texto enviado. A inferência roda por HTTP em loopback, sem proxy ou redirecionamento. A base fica no repositório e a interface não aceita documentos para indexar.
5. A API verifica sinais de perigo antes de chamar o modelo e, quando os reconhece, mostra uma orientação fixa com fonte. Nessa mesma etapa, trata perguntas sobre condições atuais, instruções adversariais conhecidas e pedidos claramente fora do escopo. Se faltarem evidências, o assistente se abstém ou pede mais detalhes.

## Reproduzir a avaliação

Com o servidor do modelo ativo, execute no diretório `backend`.

```powershell
$env:ASSISTENTE_LLM_URL = 'http://127.0.0.1:8088/v1/chat/completions'
..\.venv\Scripts\python avaliar_assistente.py --saida ../avaliacao-local.json
..\.venv\Scripts\python -m pytest -q
```

Use `--sem-llm` para executar a recuperação e o fluxo extrativo sem carregar o modelo. O avaliador registra a consulta efetiva, os trechos ranqueados, o contexto enviado, a escolha, o resultado da API, a latência e o julgamento. Em `frontend`, execute `..\.venv\Scripts\python -m pytest -q`. A pasta [evidências](evidencias/) também registra a sessão de navegação real com a API e o modelo.

O gabarito foi escrito para o projeto, e a base pequena limita o que os resultados dizem sobre perguntas novas. As regras de urgência e mascaramento podem deixar passar descrições ou formatos que não reconhecem. Para verificar alertas em vigor, vias e abrigos, consulte a prefeitura ou a Defesa Civil. Em caso de risco imediato ou necessidade de resgate, ligue 193.

### Comparação com Qwen2.5-7B

Rodamos o mesmo avaliador com os dois arquivos `qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf` e `qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf` da [revisão bb5d59e](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/tree/bb5d59e06d9551d752d08b292a50eb208b07ab1f), no mesmo diretório e com o primeiro arquivo no argumento `--model`. Para repetir, inicie outro servidor em uma porta local e aponte `ASSISTENTE_LLM_URL` para ela. Confirme a variante GGUF em `GET /v1/models`. O servidor local atende com os pesos carregados no arranque.
