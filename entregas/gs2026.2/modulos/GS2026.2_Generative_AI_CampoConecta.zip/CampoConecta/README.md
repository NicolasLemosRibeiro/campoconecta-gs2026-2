# CampoConecta | Generative AI & Advanced Nets

Global Solution 2026.2, FIAP. O assistente está na aba **Chuvas e enchentes** da plataforma CampoConecta.

- [Como rodar e reproduzir os testes](docs/generative-ai/README.md)
- [Relatório de avaliação](docs/generative-ai/relatorio.pdf)
- [Vídeo de demonstração](docs/videos/generative-ai.mp4)
- [Evidências por pergunta e configuração](docs/generative-ai/evidencias/avaliacao.json)
- [Repositório do grupo](https://github.com/murilo2318/campoconecta)
