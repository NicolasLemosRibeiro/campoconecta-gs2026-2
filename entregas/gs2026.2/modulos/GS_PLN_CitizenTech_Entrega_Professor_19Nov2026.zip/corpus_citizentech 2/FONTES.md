# Fontes e atribuições

Acesso às fontes em 12 de novembro de 2026. Os PDFs originais estão em `entrada/fontes/`. A contagem corresponde a páginas físicas do arquivo, incluindo capas e páginas sem conteúdo. O processamento considera os intervalos registrados no catálogo e gera mais de 50 trechos úteis.

1. BRASIL. Ministério da Saúde. **Cartilha de orientação à população no período de alerta de chuvas intensas**. Brasília, 2017. Arquivo de 24 páginas. A ficha catalográfica conta 22 páginas de conteúdo editorial. A licença impressa na página física 3 é CC BY-NC-SA 4.0. A autoria e a origem são preservadas nos registros derivados.

   https://bvsms.saude.gov.br/bvs/publicacoes/cartilha_orientacao_populacao_chuvas_intensas.pdf

2. BRASIL. Ministério das Cidades. Secretaria Nacional de Periferias. **Cartilha para ações comunitárias de redução de risco de desastres**. Brasília, 2024. Arquivo de 14 páginas físicas, com páginas diagramadas em duplas. O ano de publicação é confirmado no catálogo oficial do Portal Capacidades.

   https://capacidades.gov.br/capaciteca/cartilha-para-acoes-comunitarias-de-reducao-de-risco-de-desastres-deslizamento-inundacao-enxurrada-alagamento-erosao

   https://www.gov.br/cidades/pt-br/assuntos/publicacoes/arquivos/arquivos/CARTILHA2_FINAL_ESPELHADO_LOGO_ATUAL.pdf

3. BRASIL. Ministério da Saúde. **Guia de preparação e resposta à emergência em saúde pública por inundação**. Brasília, 2017. Versão disponibilizada no portal do Ministério da Saúde, com 54 páginas físicas. As referências impressas vão até a página editorial 55. A diferença decorre da montagem do arquivo digital. O manifesto preserva o hash exato da versão utilizada.

   https://www.gov.br/saude/pt-br/centrais-de-conteudo/publicacoes/svsa/enchentes/guia-de-preparacao-e-resposta-a-emergencia-em-saude-publica-por-inundacao.pdf/@@download/file

## Verificação dos encaminhamentos

DEFESA CIVIL DO MATO GROSSO DO SUL. **Quais são os números de emergência?** Publicação de 20 de janeiro de 2026. Confirma os contatos nacionais usados nos exemplos. Não foi incorporado o telefone estadual específico de Mato Grosso do Sul.

https://www.defesacivil.ms.gov.br/fale-conosco/perguntas-frequentes/10-quais-sao-os-numeros-de-emergencia/

## Ética e desenvolvimento sustentável

BRASIL. **Lei nº 13.709, de 14 de agosto de 2018**. Lei Geral de Proteção de Dados Pessoais. Foram considerados os conceitos do art. 5º, os princípios do art. 6º e a avaliação contextual da anonimização do art. 12.

https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm

NAÇÕES UNIDAS BRASIL. **ODS 11** e **ODS 13**. Relação com as metas 11.5 e 13.3, respectivamente.

https://brasil.un.org/pt-br/sdgs/11

https://brasil.un.org/pt-br/sdgs/13

## Recursos de software incluídos

QWEN TEAM. **Qwen2.5-0.5B-Instruct**. Apenas os arquivos do tokenizador estão incluídos. Modelo distribuído sob Apache 2.0. O projeto usa `AutoTokenizer.from_pretrained` localmente e não carrega os pesos do SLM.

https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct

EXPLOSION. **pt_core_news_sm**, versão 3.8.0. Pipeline de português para spaCy, distribuído sob MIT segundo os metadados do pacote. Os arquivos originais do modelo foram extraídos da distribuição oficial. O modelo foi escolhido pelo custo baixo em CPU e complementado por regras e testes específicos do tema. A qualidade em nomes de pessoas fora da amostra precisa de revisão.

https://spacy.io/models/pt

https://github.com/explosion/spacy-models/releases/tag/pt_core_news_sm-3.8.0

Os hashes locais estão em `recursos/manifesto.json`. As referências e o manifesto documentam a procedência. A inclusão das fontes preserva os avisos dos arquivos originais. A cartilha do Ministério da Saúde e suas adaptações devem respeitar a atribuição, o uso não comercial e o compartilhamento pela mesma licença.
