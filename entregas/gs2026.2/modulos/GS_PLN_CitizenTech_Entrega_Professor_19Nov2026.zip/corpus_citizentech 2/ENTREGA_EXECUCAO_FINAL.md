# PLN — Execução Final, 19/11/2026

Esta é a versão técnica sem vídeo, preparada para a integração do grupo. O vídeo de demonstração é fornecido separadamente. O projeto não exige chave de API e não treina um modelo de linguagem.

## Conteúdo

A fábrica, a interface, o notebook, o relatório de seis páginas, as fontes, os recursos locais, os quatro JSONL, o CSV e a planilha de revisão estão incluídos. Os 35 registros de revisão humana foram mantidos, com datas de 17 e 18/11. QA101, CHAT21 e CHAT32 são recusas com trecho temático vazio por intenção; os apoios de escopo e privacidade estão registrados.

## Integração com governança

Mantenha esta pasta separada do backend de relatos do CampoConecta. A fábrica é independente da API e dos pesos de Visão. O produto para consumo por outros módulos está em saida/corpus_texto.jsonl, corpus_qa.jsonl, corpus_chat.jsonl e corpus_teste.jsonl, com origem documental preservada.

O conjunto de teste deve permanecer reservado para avaliação e não ser misturado aos exemplos de treino. A combinação dos formatos em treinamento futuro exige controle da repetição das primeiras trocas de QA no chat. Não são 32 perguntas iniciais adicionais independentes.

## Verificações

A execução final repete os testes, as células do notebook, os cenários da interface e a reprodução offline. As evidências ficam em evidencias/ com o sufixo execucao_final_1911. O relatório distingue testes automáticos, assistência de IA e leitura humana.

Conferência concluída: 33 testes aprovados, 17 células do notebook executadas em ordem, oito cenários da interface aprovados e reprodução offline com quatro JSONL idênticos byte a byte. O CSV de revisão e o teste fixo também mantiveram seus hashes.
