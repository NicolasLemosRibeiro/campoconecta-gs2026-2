"""Interface local para ingestão, inspeção e exportação dos corpus."""
from io import BytesIO
import json
from pathlib import Path
import zipfile

import pandas as pd
import streamlit as st

from fabrica import (RAIZ, carregar_recursos, extrair_bytes, gerar, gerar_enviados, ler_json, ler_jsonl,
                     limpar_blocos, anonimizar, preparar_documento, segmentar)

st.set_page_config(page_title='CitizenTech | Fábrica de corpus', page_icon='📚', layout='wide')
st.title('Fábrica de corpus CitizenTech')
st.caption('Chuvas, alagamentos e prevenção de riscos urbanos | Módulo de dados do CampoConecta')
st.write('Documentos oficiais viram uma base de texto, perguntas e conversas com origem identificada. '
         'Os resultados ficam disponíveis para conferência antes de qualquer treinamento.')

@st.cache_resource
def recursos():
    return carregar_recursos()

principal, avulso, revisao = st.tabs(['Corpus do projeto', 'Nova entrada', 'Revisão da amostra'])

with principal:
    metas = ler_json(RAIZ / 'entrada/metadados.json')
    st.subheader('1. Documentos de entrada')
    st.dataframe(pd.DataFrame([{k: m[k] for k in ['arquivo', 'titulo', 'orgao', 'data', 'paginas']} for m in metas]), hide_index=True)
    modo = st.radio('Origem dos arquivos', ['Fontes incluídas no projeto', 'Enviar os três documentos'], horizontal=True)
    enviados = []
    if modo == 'Enviar os três documentos':
        enviados = st.file_uploader('Documentos oficiais do projeto', type=['pdf', 'txt', 'docx', 'html'],
                                   accept_multiple_files=True, key='fontes')
        st.caption('Os nomes e os hashes são conferidos com o catálogo. Uma nova fonte precisa de curadoria própria para perguntas e diálogos.')
    if st.button('Gerar os quatro corpus', type='primary'):
        try:
            with st.spinner('Extraindo, limpando, anonimizando e validando...'):
                if modo == 'Enviar os três documentos':
                    por_nome = {Path(f.name).name: f.getvalue() for f in enviados}
                    qualidade, arquivos = gerar_enviados(por_nome)
                else:
                    qualidade = gerar()
                    arquivos = {p.name: p.read_bytes() for p in (RAIZ / 'saida').iterdir() if p.suffix in {'.jsonl', '.json'}}
                st.session_state['resultado'] = (qualidade, arquivos)
            st.success('Corpus gerados. As verificações de formato, apoio documental e separação do teste passaram.')
        except Exception as erro:
            st.error(str(erro))
    if 'resultado' in st.session_state:
        qualidade, arquivos = st.session_state['resultado']
        st.subheader('2. Qualidade e amostras')
        resumo = []
        for nome, dados in qualidade['corpus'].items():
            resumo.append(dict(corpus=nome, exemplos=dados['exemplos'], media_tokens=dados['media_tokens'],
                               recusas=dados['recusas'], encaminhamentos=dados['encaminhamentos'], urgencias=dados['urgencias']))
        st.dataframe(pd.DataFrame(resumo), hide_index=True)
        st.write(f"{qualidade['paginas_totais']} páginas nas fontes. Perguntas do teste encontradas no treino: {qualidade['perguntas_teste_no_treino']}.")
        for nome, dados in qualidade['corpus'].items():
            with st.expander(f'Cinco exemplos de {nome}'):
                st.json(dados['exemplos_aleatorios'])
        st.subheader('3. Anonimização com dados fictícios')
        demonstracao = json.loads(arquivos['anonimizacao_ficticia.json'])
        esquerda, direita = st.columns(2)
        esquerda.text_area('Antes | documento sintético', demonstracao['antes'], height=300, disabled=True)
        direita.text_area('Depois | marcadores por tipo', demonstracao['depois'], height=300, disabled=True)
        st.caption('O documento fictício está fora dos quatro corpus. Não é guardada tabela de correspondência.')
        st.subheader('4. Exportação')
        memoria = BytesIO()
        with zipfile.ZipFile(memoria, 'w', zipfile.ZIP_DEFLATED) as pacote:
            for nome, conteudo in arquivos.items():
                pacote.writestr(nome, conteudo)
        st.download_button('Baixar corpus e evidências', memoria.getvalue(), 'Corpus_CitizenTech.zip', 'application/zip')
        for nome in ['corpus_texto.jsonl', 'corpus_qa.jsonl', 'corpus_chat.jsonl', 'corpus_teste.jsonl']:
            st.download_button(nome, arquivos[nome], nome, 'application/x-ndjson', key=nome)

with avulso:
    st.subheader('Ingestão de um novo documento')
    st.write('Esta entrada permite conferir extração, limpeza e anonimização em outros formatos. '
             'Perguntas e conversas de novas fontes precisam ser curadas com seus próprios trechos de apoio.')
    arquivo = st.file_uploader('PDF, TXT, DOCX ou HTML', type=['pdf', 'txt', 'docx', 'html', 'htm'], key='avulso')
    colado = st.text_area('Ou cole um texto', height=160)
    with st.form('metadados'):
        titulo = st.text_input('Título')
        orgao = st.text_input('Órgão emissor')
        origem = st.text_input('Link de origem')
        data = st.text_input('Data de publicação ou vigência', placeholder='2026-11 ou 2026-11-12')
        ficticio = st.checkbox('Documento fictício para demonstrar anonimização')
        enviar = st.form_submit_button('Processar entrada')
    if enviar:
        try:
            if bool(arquivo) == bool(colado.strip()):
                raise ValueError('Escolha um arquivo ou um texto colado por vez.')
            if not all(v.strip() for v in [titulo, orgao, origem, data]):
                raise ValueError('Preencha título, órgão, origem e data.')
            nome = Path(arquivo.name).name if arquivo else 'texto_colado.txt'
            conteudo = arquivo.getvalue() if arquivo else colado.encode('utf-8')
            tok, nlp = recursos()
            m = dict(arquivo=nome, titulo=titulo, orgao=orgao, origem=origem, data=data)
            blocos, medidas = preparar_documento(conteudo, m, nlp)
            st.json(medidas)
            st.text_area('Texto tratado', '\n\n'.join(b['texto'] for b in blocos), height=280)
            if ficticio:
                st.info('Documento de demonstração. Não será exportado para os corpus.')
            else:
                trechos = segmentar(blocos, m, tok)
                st.json(trechos[:5])
                payload = ''.join(json.dumps(t, ensure_ascii=False) + '\n' for t in trechos)
                st.download_button('Baixar trechos desta entrada', payload, 'trechos_nova_fonte.jsonl', 'application/x-ndjson')
        except Exception as erro:
            st.error(str(erro))

with revisao:
    st.subheader('Conferência do grupo')
    st.write('A amostra cobre pelo menos 20% de cada corpus com perguntas. '
             'Cada integrante pode conferir o trecho, o sentido da resposta e o encaminhamento antes de registrar sua revisão.')
    df = pd.read_csv(RAIZ / 'revisao.csv', keep_default_na=False)
    editado = st.data_editor(df, hide_index=True, disabled=['arquivo', 'linha', 'id', 'pergunta', 'resposta', 'trecho', 'conferencia_assistida'],
                            num_rows='fixed', key='editor_revisao')
    st.download_button('Baixar revisão preenchida', editado.to_csv(index=False).encode('utf-8-sig'), 'revisao.csv', 'text/csv')
    st.caption('O download registra o preenchimento feito nesta sessão. Substitua revisao.csv no projeto após conferir a amostra.')
