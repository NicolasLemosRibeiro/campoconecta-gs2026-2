# Conferência de 18/11/2026

A amostra mantém 35 registros revisados por Pedro Leal Murad: 26 leituras registradas em 17/11 e nove confirmadas pelo próprio Pedro nesta conversa em 18/11. Os nove IDs são CHAT17, CHAT21, CHAT30, CHAT32, T04, T08, T11, T17 e T21. As datas e os comentários do CSV distinguem essas etapas.

O CSV padronizado mantém os 13 campos técnicos. A planilha de leitura apresenta os mesmos dados em colunas organizadas. QA101, CHAT21 e CHAT32 são recusas; nesses três casos, o trecho temático permanece vazio por intenção e o apoio está nas regras de escopo ou privacidade.

Foram ajustadas quatro respostas de continuação (CHAT01, CHAT06, CHAT16 e CHAT20): retirados os inícios “Sim” ou “Não” herdados de perguntas fechadas, incompatíveis com as novas perguntas abertas. As orientações documentais foram mantidas. Os detalhes estão em evidencias/ajustes_conversacionais_1811.json. Nenhum desses quatro itens está na amostra de revisão humana de 35 registros.

O teste fixado, seus 24 registros e o hash original não foram alterados. A quantidade de exemplos permanece: 52 trechos, 112 QA, 32 diálogos e 24 testes. As evidências atuais distinguem testes automáticos e conferência assistida de revisão humana.

A amostra revisada cobre pelo menos 20% de QA, chat e teste. O vídeo de até cinco minutos, com upload e geração reais, é encaminhado separadamente desta versão técnica.
