# Fábrica de Corpus CitizenTech

## Chuvas, alagamentos e prevenção de riscos urbanos

Módulo de preparação de dados do CampoConecta, projeto CitizenTech do grupo. Transforma documentos públicos em texto para recuperação documental, pares de perguntas e respostas, conversas de atendimento e um conjunto separado de teste.

**Global Solution, 2º semestre de 2026.** O cabeçalho do PDF revisado menciona “GS 2027”, enquanto a orientação enviada pelo professor indica 2026.2. Esta entrega usa a identificação da turma e os requisitos técnicos do PDF revisado.

| Integrante | RM |
| --- | --- |
| Pedro Leal Murad | 565460 |
| Nicolas Lemos Ribeiro | 553273 |
| Murilo Benhossi | 562358 |

## Execução

Python 3.12 e CPU são suficientes. A execução foi testada em Linux com Python 3.12. Não há necessidade de GPU, chave de API ou download de pesos de um modelo de linguagem. Os documentos, o tokenizador do Qwen e o modelo NER em português estão incluídos. A instalação inicial das bibliotecas precisa de internet.

No terminal, dentro da pasta extraída do projeto, execute

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python fabrica.py
python -m unittest discover -s testes -v
```

Para abrir a interface

```bash
streamlit run app.py
```

A aba **Corpus do projeto** usa as fontes incluídas ou aceita o envio dos três PDFs. A aba **Nova entrada** recebe PDF, TXT, DOCX, HTML e texto colado, com metadados. Um documento novo pode gerar seus trechos de texto. Perguntas e diálogos exigem curadoria apoiada nessa nova fonte. A ferramenta interrompe a exportação se os documentos do catálogo forem alterados sem atualização da curadoria.

O notebook `GS_PLN_CitizenTech.ipynb` apresenta o mesmo fluxo em células. No Colab, abra o notebook e envie o ZIP deste projeto quando a primeira célula de código solicitar o pacote. O upload é necessário porque o Colab começa em uma máquina nova. O notebook confere os caminhos e extrai o pacote com validação de segurança.

## Arquivos principais

| Caminho | Conteúdo |
| --- | --- |
| `fabrica.py` | Extração, limpeza, anonimização, segmentação e geração |
| `app.py` | Interface Streamlit com upload, inspeção e downloads |
| `entrada/fontes/` | Três PDFs oficiais, somando 92 páginas físicas |
| `entrada/metadados.json` | Título, órgão, origem, data, páginas e hash de cada fonte |
| `entrada/documento_teste_ficticio.txt` | Dados sintéticos usados apenas na demonstração de anonimização |
| `curadoria/` | Perguntas e diálogos preparados, teste fixado e registro de uso de IA |
| `recursos/` | Tokenizador Qwen2.5-0.5B-Instruct e NER spaCy pt_core_news_sm |
| `saida/corpus_texto.jsonl` | Trechos com 256 a 512 tokens reais do Qwen |
| `saida/corpus_qa.jsonl` | Pares Alpaca com contexto e trecho de apoio |
| `saida/corpus_chat.jsonl` | Diálogos com system prompt e duas trocas |
| `saida/corpus_teste.jsonl` | Perguntas reservadas para avaliação posterior |
| `saida/qualidade.json` | Estatísticas e cinco amostras aleatórias de cada corpus |
| `saida/anonimizacao_ficticia.json` | Antes e depois, sem mapa de correspondência |
| `saida/conferencia_fidelidade.csv` | Conferência assistida de vinte pares |
| `revisao.csv` | Amostra de 20% ou mais para revisão humana do grupo |
| `testes/` | Testes automatizados e testes da interface |
| `Relatorio_GS_PLN_CitizenTech.pdf` | Relatório acadêmico de seis páginas |

## Decisões de dados

São preservados acentos, pontuação, maiúsculas e o texto completo. Não há stemming nem remoção de stop words. Os recortes por páginas retiram capas, sumários, expedientes e referências finais. O código remove ruído de diagramação, números isolados, URLs em linhas avulsas e cabeçalhos recorrentes e recompõe palavras quebradas no fim da linha.

CPF, e-mail e telefone usam expressões regulares. Nomes usam NER em português e regras complementares para campos identificados. Exceções institucionais e falsos positivos de vocabulário de atendimento estão explícitos no código. Os números curtos de serviços de emergência são preservados. O documento sintético nunca entra nos corpus.

O tokenizador é carregado por `AutoTokenizer.from_pretrained` com `local_files_only=True`. São usados os arquivos originais de `Qwen/Qwen2.5-0.5B-Instruct`. O modelo spaCy incluído é `pt_core_news_sm` 3.8.0. Os hashes dos recursos estão em `recursos/manifesto.json`.

A segmentação particiona frases e busca grupos de 256 a 512 tokens, sem sobreposição nem preenchimento artificial. Frases excepcionais com mais de 240 tokens são divididas por limites de palavras. A última parte não é descartada. Os testes reúnem todos os trechos e comparam o conteúdo com o texto preparado de cada documento.

## Forma no treino e fatos no contexto

O comportamento de atendimento é ensinado pelas perguntas e conversas. Cada resposta factual recebe contexto documental no `input` do QA ou na mensagem `system` do diálogo. Assim, o exemplo mostra como responder a partir de uma fonte. Os nomes, URLs e datas dos documentos continuam disponíveis como metadados para a recuperação documental.

As edições de 2017 são fontes históricas de orientação geral. Elas não comprovam disponibilidade atual de abrigos, protocolos clínicos, calendários de vacinação ou canais locais. Essas informações exigem fonte oficial atual. As perguntas de teste verificam justamente se o futuro modelo sabe reconhecer esse limite.

## Avaliação e revisão

`python -m unittest discover -s testes -v` executa 33 testes, incluindo os quatro formatos, texto colado, anonimização, preservação das exceções, contagem pelo Qwen, integridade dos documentos, ausência de vazamento e encaminhamento em urgências. O mesmo fluxo recebe os bytes dos três PDFs enviados e verifica se as saídas são idênticas. A validação literal do trecho verifica rastreabilidade. O sentido completo da resposta também precisa de leitura crítica.

O notebook foi executado em sequência com IPython, com saídas salvas. A execução atual das 17 células está em evidencias/notebook_1811.json, e a execução anterior está preservada separadamente. A aparência e o transporte de upload no navegador do aluno serão conferidos durante a gravação.

A redação e o código tiveram assistência de IA. O registro está em `curadoria/uso_ia.md`. A amostra de revisão humana contém 23 pares, 7 diálogos e 5 perguntas de teste. Os 35 exemplos têm leitura humana registrada por Pedro: 26 em 17/11 e nove confirmados em 18/11. A conferência assistida de 20 pares está registrada separadamente. Não é uma avaliação de desempenho de um SLM, pois esta atividade termina na preparação dos corpus.

O conjunto de teste foi definido antes da base de treino. Seu hash fica em `curadoria/teste_fixo.sha256.json`. A geração verifica esse hash e compara perguntas normalizadas entre teste e treino. O documento-teste sintético foi deliberadamente mantido fora dos quatro JSONL.

## Relação com o projeto integrado

O CampoConecta recebe relatos urbanos e organiza a triagem. Esta entrega fornece uma base documental com origem identificada para orientar cidadãos sobre chuvas e alagamentos e para preparar o comportamento de um futuro atendente. O arquivo de texto pode alimentar a recuperação documental. O vínculo com os outros módulos é o problema público e a estrutura de dados. A execução desta fábrica é independente da API do protótipo.

## Revisão final da entrega

Os resultados executados e as evidências dos testes estão em `evidencias/`. A revisão humana dos 35 exemplos está registrada. O vídeo de demonstração com upload e geração reais será fornecido separadamente deste ZIP. Depois, envie um único link do GitHub ou da pasta compartilhada com o conteúdo deste pacote. O relatório distingue o trabalho concluído das etapas de apresentação.

## Fontes e condições de uso

As referências completas e os links estão em `FONTES.md` e no catálogo JSON. As fontes oficiais e os recursos de terceiros mantêm seus autores e licenças. As origens dos arquivos incluídos estão documentadas. O arquivo `FONTES.md` informa a atribuição do tokenizador e do modelo NER.

## Histórico da conferência de 16/11/2026

A execução original do aluno no Colab está preservada em `evidencias/notebook_colab_original.ipynb`, sem erros e com 31 testes aprovados em 57,469 segundos. Após essa execução, foram acrescentadas referências para os cinco itens de teste da amostra e para o canal 192 no diálogo CHAT30. Os apoios são reproduzidos em `saida/apoios_revisao.json` e exibidos em `revisao.csv`. As perguntas, respostas e o hash do teste fixado permanecem intactos.

A extração recompõe os artefatos tipográficos “T êm” e “T ente”, conferidos na cartilha comunitária. Títulos e legendas da diagramação continuam presentes em alguns contextos. A página e a fonte devem acompanhar a leitura. A existência literal de uma passagem não demonstra, por si só, que uma resposta é fiel.

Os 35 exemplos da amostra foram examinados com assistência de IA na conversa. Os 35 registros têm revisão humana concluída; a assistência de IA é identificada separadamente. O vídeo será produzido pelo grupo.

## Revisão adicional

O CSV avulso enviado na conversa tinha 11 colunas; o CSV interno deste pacote tem 13, incluindo fontes_apoio e justificativa_assistida. Use a versão interna. A conferência assistida agora distingue recusas sem fonte de respostas documentais. Os campos humanos foram registrados com base nas confirmações explícitas de Pedro. O teste fixado, QA e texto puro foram preservados. Em 18/11, foram ajustados quatro inícios de respostas de continuação no chat, sem mudar as orientações documentais. Consulte REVISAO_FINAL.md e evidencias/ajustes_conversacionais_1811.json.

Os 32 diálogos reutilizam o primeiro par de QA e acrescentam continuação. São transformações conversacionais, não 32 perguntas iniciais independentes. A combinação dos formatos em treino futuro exige controle de ponderação para evitar sobre-representação.


## Estado atual em 18/11/2026

Pedro confirmou a leitura e a aprovação dos nove itens restantes nesta conversa. O CSV registra 35 exemplos revisados, com datas de 17 e 18/11. Menções anteriores a pendência descrevem etapas históricas. A conferência assistida continua identificada separadamente. O vídeo é fornecido separadamente desta versão técnica conferida.

## Abrir a interface no Cursor
Depois de instalar as dependências, execute na pasta do projeto:

    python -m streamlit run app.py

Abra http://localhost:8501 no navegador. Na aba Corpus do projeto, selecione Fontes incluídas no projeto e clique em Gerar os quatro corpus. O comando python fabrica.py não substitui a abertura da interface.
