# Conferência do vídeo de PLN

O vídeo separado GS_PLN_CitizenTech_Video_Final.mp4 tem 4 minutos e 52,625 segundos, resolução de 1920 × 1200 e áudio AAC. A decodificação integral de áudio e vídeo terminou sem erros. Foram conferidos a transcrição completa e quadros de todas as etapas.

A narração apresenta os integrantes, três fontes públicas, anonimização fictícia, quatro JSONL (52/112/32/24), 35 exemplos revisados, assistência de IA registrada à parte, três recusas sem trecho de cartilha e limitações do teste. Não afirma treinamento de modelo de linguagem nem deixa nove revisões pendentes. O fluxo visual mostra envio dos documentos, geração, anonimização e exportação. Algumas telas completas têm texto pequeno e há interface do navegador/sistema; isso pode ser melhorado visualmente, mas não impede acompanhar o fluxo. A revisão não substitui o enunciado e não garante nota.
