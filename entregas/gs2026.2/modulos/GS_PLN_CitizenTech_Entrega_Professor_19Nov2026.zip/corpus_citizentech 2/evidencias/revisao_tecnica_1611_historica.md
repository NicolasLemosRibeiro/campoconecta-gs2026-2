# Conferência dos três trabalhos

Revisão técnica de 16/11/2026. Originais preservados. Os pacotes revisados são cópias separadas e não foram enviados ao Portal nem publicados.

## Resultado por disciplina

| Trabalho | Conferência executada | Resultado | Pendência |
| --- | --- | --- | --- |
| PLN | Geração, 33 testes, 8 cenários da interface, reprodução sem rede e notebook via IPython | Quatro JSONL reproduzidos byte a byte; notebook com 17 células de código executadas sem erro | Revisão humana dos 35 registros e vídeo de até 5 minutos |
| Visão | 480 imagens, hashes, grupos, similaridade perceptual, 568 caixas, avaliação do checkpoint e 35 testes do backend | Mesmas métricas do relatório; nenhuma cópia exata ou par perceptual com distância até 4 entre conjuntos | Gravar vídeo próprio; validar abertura e interação no Mac |
| Quântica | Benchmark completo, 120 execuções, comparação dos resultados e leitura do PDF | Todos os indicadores operacionais reproduzidos; tempos variam | Conferir eventual exigência adicional do professor |

Os PDFs têm 6, 2 e 3 páginas, respectivamente, e foram renderizados para inspeção visual. Não foram encontrados cortes ou sobreposições evidentes. Os requisitos foram conferidos com os materiais presentes nos pacotes; o Portal autenticado não foi acessado.

## PLN: o que a análise externa acertou e o que precisa de correção

O CSV avulso tinha 11 colunas. O CSV interno do ZIP tem 13 e já contém fontes de apoio e justificativas adicionais. A versão interna deve acompanhar o notebook. A revisão humana está realmente pendente; nenhum nome, assinatura ou aprovação humana foi inventado.

A declaração de conferência foi ajustada para distinguir respostas documentais das recusas sem trecho. Não é necessário inventar fonte para uma recusa de currículo ou exposição de CPF.

O teste usa perguntas diferentes sobre as mesmas fontes. Isso caracteriza uma avaliação dentro do domínio, não demonstra por si só vazamento indevido. Não mede generalização a documentos inéditos. O hash confirma integridade do arquivo; isoladamente, não prova a data em que ele foi criado. A ausência de perguntas idênticas também não prova independência semântica completa.

Os 32 diálogos reutilizam pergunta e resposta de QA na primeira troca e acrescentam uma continuação. São versões conversacionais dos mesmos exemplos. Não devem ser contados como 32 perguntas iniciais independentes. Um futuro treino que combinar os formatos precisará controlar a ponderação dessa repetição. Os mínimos de 112 QA e 32 conversas foram preservados.

Os excertos de apoio podem corresponder a páginas físicas que terminam no meio de uma frase. Isso não comprova defeito no algoritmo de segmentação do corpus de texto: os 52 trechos passaram na reconstrução de conteúdo e na contagem de tokens. Persistem ruídos editoriais em partes das fontes; o sistema não transforma orientação histórica em protocolo clínico atual.

Não houve treinamento de SLM ou LoRA. A aprovação dos testes técnicos não substitui a leitura humana do conteúdo.

## Visão: limites e ajustes

O checkpoint integrado ao aplicativo foi reavaliado em 80 imagens de validação e 100 de teste. O limiar foi escolhido exclusivamente na validação. O resultado reproduziu 34 verdadeiros positivos, 70 falsos positivos e 73 falsos negativos, com precisão de 32,69%, recall de 31,78%, F1 de 32,23%, AP@50 de 25,39% e mAP@50–95 de 7,72%.

Esse desempenho é modesto. O detector serve como demonstração de triagem sujeita a revisão, sem validar uso autônomo ou confiabilidade operacional. A generalização para vias brasileiras não foi comprovada.

Nesta conferência, a média local foi 42,91 ms por imagem, cerca de 23,30 FPS, em CPU e versões registradas em `revisao/metricas.json`. O relatório preserva a medição histórica de 15,20 ms em outro ambiente. Não se deve prometer esse tempo no Mac do apresentador.

O notebook contém uma execução histórica com GPU T4; o relatório corresponde ao checkpoint CPU entregue. Essa diferença já estava declarada e foi reforçada. O treinamento de 20 épocas não foi repetido nesta revisão; foram repetidas inferência, avaliação e testes da API com os pesos existentes. A preparação original a partir do arquivo integral RDD2022 também não foi repetida.

A célula de localização do notebook foi corrigida para funcionar quando aberto na raiz ou na própria pasta do notebook e para oferecer upload no Colab. Essa célula foi executada nos dois caminhos locais. O arquivo não foi marcado como integralmente reexecutado nesta revisão.

Os pesos são idênticos ao hash registrado. Não houve pares entre conjuntos com distância perceptual de até 4, mas sem identificadores de percurso não é possível garantir vias distintas. Front e RPA possuem documentação de vídeos antigos; isso não substitui o vídeo desta disciplina.

## Quântica: interpretação

O benchmark é inteiramente clássico e sintético. Os 120 registros reproduziram os mesmos indicadores operacionais do original. Não houve execução em processador quântico nem medição de vantagem quântica.

No cenário com 96 pedidos, os dois métodos deixam 48 pendentes porque há 48 turnos. O gargalo demonstrado é capacidade. A escolha futura de rotas com recozimento quântico é uma hipótese condicional, sujeita a comparação com bons métodos clássicos. O estudo não demonstra gargalo computacional atual nem permite prometer que o quântico resolverá falta de equipes.

O PDF separa triagem textual e agenda, registra efeitos territoriais e propõe controles de ética, proteção de dados e ODS. O anexo foi mantido sem modificar resultados históricos. A nova execução está em `experimento/resultados_revisao`.

## Antes da entrega

1. Conferir e assinar de verdade a amostra de PLN em `revisao.csv`.
2. Gravar vídeos distintos de PLN e Visão, com demonstração real e narração. O limite confirmado de PLN é 5 minutos. O material de Visão incluído não confirma duração específica; o roteiro propõe cerca de 4 minutos.
3. Confirmar no Portal formato, prazo e exigências do professor. Nenhum recibo de envio foi obtido.
4. Guardar os originais. Usar os ZIPs revisados desta pasta para a demonstração.


## Estado atual em 18/11/2026

Pedro confirmou a leitura e a aprovação dos nove itens restantes nesta conversa. O CSV registra 35 exemplos revisados, com datas de 17 e 18/11. Menções anteriores a pendência descrevem etapas históricas. A conferência assistida continua identificada separadamente. Falta concluir o vídeo e verificar a entrega.
