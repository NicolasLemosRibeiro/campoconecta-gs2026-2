# Roteiros para gravação em 17/11

Use uma gravação diferente para cada disciplina. Faça um ensaio antes de gravar e feche janelas com informações pessoais. Os textos são sugestões de fala: adapte ao seu jeito e aos resultados que aparecerem na tela. Não leia uma métrica que não corresponda ao modelo exibido.

## PLN — aproximadamente 4min40s; limite de 5 minutos

| Tempo | Mostrar | Fala sugerida |
| --- | --- | --- |
| 0:00–0:30 | Título e interface | Nosso módulo do CitizenTech organiza documentos públicos sobre chuvas e alagamentos. O objetivo é preparar uma base rastreável para um futuro atendente do CampoConecta. Esta entrega prepara dados; não treinou um modelo de linguagem. |
| 0:30–1:10 | Catálogo e três PDFs | Usamos três publicações oficiais, somando 92 páginas físicas. Cada fonte tem título, órgão, data e hash. A aplicação funciona em CPU, com tokenizador e reconhecimento de nomes locais, sem chave de API. |
| 1:10–1:55 | Selecionar os três documentos e gerar | A fábrica extrai, limpa, anonimiza e organiza o conteúdo. Temos 52 trechos de texto, 112 pares de perguntas e respostas, 32 diálogos e 24 perguntas de teste. A contagem dos trechos usa o tokenizador Qwen. Se a geração levar mais tempo, reduza a fala de abertura; não finja que o processamento já terminou. |
| 1:55–2:40 | Aba Nova entrada com documento fictício | Aqui usamos uma ficha inteiramente inventada. Nomes, CPF, e-mail e telefone são substituídos por marcadores. Essa ficha não entra nos corpus. As exceções preservam instituições e termos relevantes. O reconhecimento de nomes tem limitações e não garante anonimização de qualquer documento. |
| 2:40–3:25 | Um QA com apoio e um diálogo | A resposta acompanha um contexto e uma origem. Os diálogos acrescentam uma segunda troca a pares já usados em QA. Em urgência, o atendimento encaminha para o serviço apropriado e não promete acionar equipes. |
| 3:25–4:05 | Teste separado e evidências | As 24 perguntas de teste ficam separadas. Conferimos integridade, formatos, contagem e perguntas coincidentes. Os 33 testes e os oito cenários da interface passaram. A reprodução gerou os mesmos quatro arquivos sem conexões externas. |
| 4:05–4:40 | Revisão e quatro arquivos | A amostra de 35 exemplos recebe leitura humana do grupo. A análise assistida fica identificada separadamente. Os documentos antigos não comprovam serviços ou protocolos atuais. A entrega reúne código, fontes, corpus, relatório e evidências. |

Só diga que a revisão humana foi concluída depois de preencher os campos com leitura real. Se ainda estiver pendente, declare isso. Para gravar, use o CSV interno do pacote, não o CSV avulso antigo.

Execução na pasta `corpus_citizentech`, após instalar as dependências:

```bash
python fabrica.py
python -m streamlit run app.py
```

## Visão — aproximadamente 4 minutos; confirmar limite no Portal

| Tempo | Mostrar | Fala sugerida |
| --- | --- | --- |
| 0:00–0:30 | Módulo de pavimentação | O módulo detecta possíveis buracos em fotos de vias para apoiar a seleção de locais para vistoria. A confiança é uma pontuação do detector; a gravidade continua com a equipe técnica. |
| 0:30–1:10 | Dados e tabela de divisão | Usamos 480 imagens do RDD2022 da Índia, com a classe D40. São 300 de treino, 80 de validação e 100 de teste. Conferimos hashes, grupos de identificadores e similaridade perceptual. Isso reduz vazamento, sem comprovar que todas as vias são diferentes. |
| 1:10–1:45 | Treinamento e métricas históricas | O YOLO11n foi ajustado por 20 épocas a partir de pesos COCO. O modelo integrado ao aplicativo é o checkpoint CPU. O limiar de 0,15 foi escolhido na validação. No teste, esse modelo teve 32,7% de precisão e 31,8% de recall. O resultado é modesto e exige revisão humana. |
| 1:45–2:45 | Enviar imagem com detecção e imagem sem caixa | Esta foto passa pela API com os pesos entregues e volta com as caixas e a confiança. Agora mostro uma imagem sem detecção. A ausência de caixa não comprova que a via esteja segura. Use `India_008389.jpg` e `India_000145.jpg` da pasta de demonstração; confira o retorno real antes de narrar. |
| 2:45–3:20 | Exemplos de acerto, falso positivo e falso negativo | Um acerto localiza um buraco anotado. Uma textura pode produzir falso positivo, e uma região escura pode esconder um dano. Esses exemplos ajudam a explicar por que a vistoria permanece necessária. |
| 3:20–4:00 | Evidência de avaliação e conclusão | A avaliação repetida reproduziu os resultados do checkpoint. A velocidade muda com o computador e não representa garantia para o Mac. O notebook contém outra execução no Colab, identificada separadamente. Precisamos avaliar imagens brasileiras antes de qualquer uso operacional. |

Não use as métricas do treinamento T4 para narrar o modelo CPU da API. Não é necessário retreinar ao vivo. Os comandos completos da API e do Streamlit estão em `entregas_externas/visao/LEIAME.md`.

## Quântica — apoio de fala, se o professor pedir vídeo

O material recebido não confirma vídeo obrigatório nem duração. Este apoio pode ser usado em uma apresentação de aproximadamente 3 minutos.

1. Mostre o problema: depois de aprovar um relato, ainda é preciso decidir equipe e horário de visita.
2. Mostre os três cenários sintéticos e a comparação entre regra gulosa e otimização clássica exata. Aponte que, em 96 pedidos, faltam turnos; não faltou velocidade de cálculo.
3. Explique o roadmap: medir atendimento real, melhorar o método clássico e só testar seleção quântica de rotas se houver dificuldade relevante que permaneça.
4. Diga expressamente: não executamos algoritmo quântico e não demonstramos vantagem quântica. O anexo reproduz um experimento clássico.
5. Conclua com a distribuição dos atrasos por território, revisão humana de prioridades e uso mínimo de dados. São critérios para um piloto, não impactos já medidos em pessoas.

Para repetir o benchmark sem sobrescrever a referência:

```bash
cd GS_Quantica_CampoConecta/experimento
python benchmark.py resultados_gravacao
```

## Preparação prática

- Extraia primeiro o ZIP consolidado e depois o pacote da disciplina.
- Instale e abra tudo antes de iniciar a captura de tela. Deixe as imagens de demonstração e os documentos à mão.
- Grave a tela com o microfone selecionado e faça um trecho curto para confirmar o áudio.
- Mostre resultados reais e mantenha nomes, RMs e títulos coerentes com a entrega.
- Assista ao vídeo inteiro, confira áudio e duração e teste o link de compartilhamento antes de enviar ao professor.


## Estado atual em 18/11/2026

Pedro confirmou a leitura e a aprovação dos nove itens restantes nesta conversa. O CSV registra 35 exemplos revisados, com datas de 17 e 18/11. Menções anteriores a pendência descrevem etapas históricas. A conferência assistida continua identificada separadamente. Falta concluir o vídeo e verificar a entrega.
