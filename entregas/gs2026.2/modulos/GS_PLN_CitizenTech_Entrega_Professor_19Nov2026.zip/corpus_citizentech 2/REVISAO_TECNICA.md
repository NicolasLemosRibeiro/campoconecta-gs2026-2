# Conferência técnica de PLN - 18/11/2026

A versão atual foi gerada e conferida localmente com Python 3.12. As 17 células de código do notebook foram executadas em ordem, incluindo a instalação das dependências e os 33 testes da suíte. As evidências originais do Colab ficam separadas.

- Ingestão: PDF, TXT, DOCX, HTML e texto colado verificados.
- Fontes: três documentos oficiais, 92 páginas físicas e hashes preservados.
- Corpus: 52 trechos de texto, 112 QA, 32 diálogos e 24 testes.
- Segmentação: tokenizador Qwen local; 256 a 512 tokens, com reconstrução do conteúdo para conferir perdas.
- Anonimização: nomes, CPF, telefone e e-mail em ficha sintética; documento de teste fora dos corpus.
- Teste: 24 perguntas fixadas por hash; nenhuma pergunta idêntica após normalização no treino. As fontes são compartilhadas, portanto não se demonstra generalização para documentos inéditos.
- Reprodução: quatro JSONL idênticos byte a byte em nova geração com conexões externas bloqueadas.
- Interface: oito cenários AppTest aprovados, além do processamento dos bytes dos PDFs pelos testes.
- Revisão: 35 registros com leitura humana confirmada por Pedro, com datas de 17 e 18/11. A assistência de IA fica identificada separadamente.

Foram ajustados quatro inícios de respostas de continuação no chat (CHAT01, CHAT06, CHAT16 e CHAT20). Esses itens não pertencem à amostra humana de 35. O detalhe das alterações e os hashes atuais constam em evidencias/. QA, texto puro e teste permaneceram byte a byte iguais à referência anterior.

Não houve treino de modelo de linguagem. O trabalho termina na preparação dos dados. O reaproveitamento da primeira troca de QA em chat e as limitações do NER são declarados. A análise assistida não é contada como revisão humana.

O vídeo, com upload e geração reais e limite de cinco minutos, é encaminhado separadamente. AppTest não substitui essa gravação.
