# Registro de elaboração assistida

A implementação e a primeira redação dos exemplos foram produzidas com assistência do ChatGPT/Codex, da OpenAI, nesta sessão. A interface identifica a família GPT-6. As perguntas, respostas e conversas foram salvas em `qa_base.jsonl` e `chat_base.jsonl`. A execução do projeto não chama esse serviço nem depende de chave de API.

## Orientação usada na elaboração

“Monte uma fábrica de corpus em Python para o CitizenTech/CampoConecta, no tema de chuvas e alagamentos. Use documentos oficiais e linguagem clara. Separe o teste antes do treino. Produza perguntas distintas, com escrita cotidiana e respostas corretas. Cada resposta factual precisa de passagem de apoio. Nas conversas, a segunda pergunta deve depender do histórico. Inclua recusas, limites clínicos e estruturais, privacidade e encaminhamentos de emergência. Não invente dados locais, prazos, abrigos ou benefícios. Salve as saídas para execução sem API e registre o que ainda precisa de revisão humana.”

O texto acima registra a orientação editorial consolidada nesta sessão. Não houve chamada programática de geração a outro modelo, nem uso de Ollama ou de LLM como juiz externo. O `system prompt` efetivamente incluído no corpus está em `fabrica.py` e nas mensagens de cada conversa.

## Conferência

Os testes verificam formato, rastreabilidade literal, ausência de perguntas de teste no treino e casos de segurança. A conferência assistida de 20 pares está em `saida/conferencia_fidelidade.csv`. Ela não substitui uma revisão humana.

`revisao.csv` seleciona 23 pares de QA, 7 diálogos e 5 perguntas de teste. São pelo menos 20% de cada arquivo. A versão atual registra 35 leituras humanas por Pedro: 26 em 17/11 e nove confirmadas em 18/11. Os campos de alteração, comentário, nome e data registram essas confirmações. A origem dos registros humanos é a declaração do próprio revisor na conversa.

## Conferência adicional em 16/11/2026

A conferência assistida examinou os 35 exemplos apresentados pelo aluno. Foram acrescentados apoios documentais aos cinco itens de teste da amostra e ao número 192 em CHAT30. O conjunto de teste fixado não foi editado. A etapa de 16/11 não preencheu autoria humana; os 26 registros posteriores estão identificados no CSV. As justificativas adicionais ficam em `revisao.csv` e `curadoria/apoios_revisao.json`.


## Estado atual em 18/11/2026

Pedro confirmou a leitura e a aprovação dos nove itens restantes nesta conversa. O CSV registra 35 exemplos revisados, com datas de 17 e 18/11. Menções anteriores a pendência descrevem etapas históricas. A conferência assistida continua identificada separadamente. Falta concluir o vídeo e verificar a entrega.
