"""Testes de regressão e critérios verificáveis do enunciado."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import re
import sys
import tempfile
import unittest

from docx import Document

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fabrica import (RAIZ, EXCECOES, PADROES, anonimizar, carregar_recursos, chave_pergunta,
                     extrair_bytes, gerar, gerar_enviados, ler_json, ler_jsonl, limpar_blocos, normalizar,
                     preparar_documento, segmentar, sem_duplicatas)


class TestFabrica(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tok, cls.nlp = carregar_recursos()
        cls.meta = ler_json(RAIZ / 'entrada/metadados.json')
        cls.dados = {t: ler_jsonl(RAIZ / 'saida' / f'corpus_{t}.jsonl') for t in ['texto', 'qa', 'chat', 'teste']}
        cls.qualidade = ler_json(RAIZ / 'saida/qualidade.json')

    def test_01_fontes_e_paginas(self):
        self.assertTrue(3 <= len(self.meta) <= 8)
        self.assertGreaterEqual(sum(m['paginas'] for m in self.meta), 50)
        for m in self.meta:
            with self.subTest(fonte=m['arquivo']):
                for k in ['titulo', 'orgao', 'origem', 'data', 'arquivo']:
                    self.assertTrue(m[k])
                self.assertEqual(sha256((RAIZ / 'entrada/fontes' / m['arquivo']).read_bytes()).hexdigest(), m['sha256'])

    def test_02_pdf(self):
        b = extrair_bytes((RAIZ / 'entrada/fontes/chuvas_saude.pdf').read_bytes(), 'chuvas.pdf')
        self.assertEqual(len(b), 24)
        self.assertIn('leptospirose', ' '.join(x['texto'].lower() for x in b))
        self.assertEqual(b[4]['pagina'], 5)

    def test_03_txt_utf8_e_legado(self):
        for encoding in ['utf-8-sig', 'cp1252']:
            with self.subTest(encoding=encoding):
                b = extrair_bytes('Orientação com ação e proteção.'.encode(encoding), 'entrada.txt')
                self.assertEqual(b[0]['texto'], 'Orientação com ação e proteção.')

    def test_04_docx_secao_e_tabela(self):
        d = Document()
        d.add_heading('Plano da família', level=1)
        d.add_paragraph('Combine um ponto de encontro.')
        t = d.add_table(rows=1, cols=2)
        t.cell(0, 0).text = 'Emergência'; t.cell(0, 1).text = '193'
        stream = BytesIO(); d.save(stream)
        b = extrair_bytes(stream.getvalue(), 'plano.docx')
        self.assertEqual(b[0]['secao'], 'Plano da família')
        self.assertTrue(any('193' in x['texto'] for x in b))

    def test_05_html_remove_codigo_e_preserva_secao(self):
        h = '<html><nav>Menu</nav><main><h1>Chuva</h1><p>Evite contato com a lama.</p><ul><li>Primeiro item</li></ul></main><script>segredo()</script></html>'
        b = extrair_bytes(h.encode(), 'pagina.html')
        self.assertEqual(b[0]['secao'], 'Chuva')
        self.assertEqual(len(b), 2)
        self.assertNotIn('segredo', str(b))
        self.assertNotIn('Menu', str(b))

    def test_06_texto_colado(self):
        b = extrair_bytes('A chuva exige atenção.'.encode(), 'texto_colado.txt')
        self.assertIn('atenção', b[0]['texto'])

    def test_07_formato_invalido(self):
        with self.assertRaisesRegex(ValueError, 'Formato não aceito'):
            extrair_bytes(b'conteudo', 'arquivo.exe')

    def test_08_normalizacao_preserva_lingua(self):
        self.assertEqual(normalizar('A\u00e7a\u0303o  “PÚBLICA”\t'), 'Ação "PÚBLICA"')
        self.assertEqual(normalizar('não é para remover as palavras'), 'não é para remover as palavras')

    def test_09_ruido_e_hifen(self):
        b = [dict(texto=f'CABEÇALHO INSTITUCIONAL\nprote-\nção contra enchentes.\nhttps://exemplo.gov.br\n{i}', pagina=i, secao='Cuidados') for i in range(1, 4)]
        limpos, removidas = limpar_blocos(b)
        self.assertEqual(limpos[0]['texto'], 'proteção contra enchentes.')
        self.assertGreaterEqual(removidas, 9)

    def test_10_mascara_cpf_email_telefone(self):
        texto = 'CPF: 000.111.222-33. E-mail: exemplo@example.invalid. Telefone: (11) 90000-0000.'
        depois, c = anonimizar(texto, self.nlp)
        for tipo in ['CPF', 'EMAIL', 'TELEFONE']:
            self.assertIn('[' + tipo + ']', depois)
            self.assertGreaterEqual(c[tipo], 1)
        self.assertNotIn('000.111', depois)

    def test_11_nomes_rotulados_e_ner(self):
        for texto, esperado in [('Nome: Marina Ferreira Campos\nRelato: teste', 'Marina Ferreira Campos'),
                                 ('Rafael de Souza Lima solicitou orientação.', 'Rafael de Souza Lima')]:
            with self.subTest(texto=texto):
                depois, c = anonimizar(texto, self.nlp)
                self.assertNotIn(esperado, depois)
                self.assertIn('[NOME]', depois)

    def test_12_excecoes_e_telefones_publicos(self):
        texto = 'Lei Maria da Penha; Fiocruz; Luiz Inácio Lula da Silva. SAMU 192, Bombeiros 193 e Defesa Civil 199.'
        depois, _ = anonimizar(texto, self.nlp)
        self.assertEqual(depois, texto)

    def test_13_falsos_positivos_de_atendimento(self):
        for texto in ['Sim. Procure a unidade.', 'Ligue agora para os Bombeiros pelo 193.',
                      'Converse com a equipe de saúde.', 'Solicite vistoria da Defesa Civil.']:
            with self.subTest(texto=texto):
                depois, _ = anonimizar(texto, self.nlp)
                self.assertEqual(depois, texto)

    def test_14_documento_ficticio_excluido(self):
        d = ler_json(RAIZ / 'saida/anonimizacao_ficticia.json')
        for valor in ['Marina Ferreira Campos', 'Rafael de Souza Lima', '000.111.222-33', 'marina.campos@example.invalid', '(11) 90000-0000']:
            self.assertNotIn(valor, d['depois'])
            for corpus in self.dados.values():
                self.assertNotIn(valor, json.dumps(corpus, ensure_ascii=False))
        self.assertIn('Relato fictício:', d['depois'])
        self.assertFalse(d['incluido_nos_corpus'])
        self.assertFalse(d['tabela_correspondencia'])

    def test_15_quantidades(self):
        for t, minimo in [('texto', 50), ('qa', 100), ('chat', 30), ('teste', 20)]:
            self.assertGreaterEqual(len(self.dados[t]), minimo)
        self.assertGreaterEqual(len({e['fonte'] for e in self.dados['qa'] if e['fonte']}), 3)

    def test_16_tokens_reais_e_metadados(self):
        for e in self.dados['texto']:
            with self.subTest(id=e['id']):
                n = len(self.tok.encode(e['text'], add_special_tokens=False))
                self.assertEqual(n, e['tokens'])
                self.assertTrue(256 <= n <= 512)
                for campo in ['fonte', 'secao', 'data', 'titulo', 'orgao', 'origem', 'paginas']:
                    self.assertTrue(e[campo])

    def test_17_segmentacao_sem_perder_cauda(self):
        for m in self.meta:
            blocos, _ = preparar_documento((RAIZ / 'entrada/fontes' / m['arquivo']).read_bytes(), m, self.nlp)
            original = normalizar(' '.join(b['texto'] for b in blocos))
            reunido = normalizar(' '.join(e['text'] for e in self.dados['texto'] if e['fonte'] == m['arquivo']))
            self.assertEqual(original, reunido)

    def test_18_entrada_curta_nao_inventa_volume(self):
        with self.assertRaisesRegex(ValueError, 'Não foi possível segmentar'):
            segmentar([dict(texto='Um texto muito curto.', pagina=None, secao='Teste')], {'arquivo': 'teste.txt'}, self.tok)

    def test_19_apoio_literal_qa(self):
        fontes = {}
        for m in self.meta:
            b, _ = preparar_documento((RAIZ / 'entrada/fontes' / m['arquivo']).read_bytes(), m, self.nlp)
            fontes[m['arquivo']] = {x['pagina']: x['texto'] for x in b}
        for e in self.dados['qa']:
            if e['fonte']:
                self.assertIn(e['trecho'], fontes[e['fonte']][e['pagina']])
                self.assertIn(e['trecho'], e['input'])
            else:
                self.assertEqual(e['trecho'], '')
                self.assertEqual(e['categoria'], 'recusa')

    def test_20_dialogos_historico_e_formato_qwen(self):
        for e in self.dados['chat']:
            self.assertEqual([m['role'] for m in e['messages']], ['system', 'user', 'assistant', 'user', 'assistant'])
            self.assertTrue(e['messages'][3]['content'])
            self.assertNotEqual(e['messages'][1]['content'], e['messages'][3]['content'])
            serializado = self.tok.apply_chat_template(e['messages'], tokenize=False)
            self.assertIn('<|im_start|>assistant', serializado)
        self.assertGreaterEqual(sum(e['categoria'] != 'direta' for e in self.dados['chat']), 10)

    def test_21_urgencias_encaminhadas(self):
        esperados = {'QA107': '193', 'QA108': '192', 'QA109': '199', 'QA110': '192'}
        for e in self.dados['qa']:
            if e['id'] in esperados:
                self.assertIn(esperados[e['id']], e['output'])
                self.assertIn('imediat' if e['id'] in {'QA109', 'QA110'} else 'agora', e['output'])
        for e in self.dados['chat']:
            if e['categoria'] == 'urgencia':
                self.assertRegex(e['messages'][2]['content'], r'19[239]')
                self.assertRegex(e['messages'][4]['content'], r'19[239]|médico imediato')

    def test_22_teste_previo_congelado_sem_vazamento(self):
        p = RAIZ / 'curadoria/teste_fixo.jsonl'
        self.assertEqual(sha256(p.read_bytes()).hexdigest(), ler_json(RAIZ / 'curadoria/teste_fixo.sha256.json')['sha256'])
        self.assertEqual(p.read_bytes(), (RAIZ / 'saida/corpus_teste.jsonl').read_bytes())
        perguntas = {chave_pergunta(e['instruction']) for e in self.dados['qa']}
        perguntas.update(chave_pergunta(m['content']) for e in self.dados['chat'] for m in e['messages'] if m['role'] == 'user')
        self.assertFalse(perguntas & {chave_pergunta(e['pergunta']) for e in self.dados['teste']})
        c = Counter(e['tipo'] for e in self.dados['teste'])
        self.assertGreaterEqual(c['fora_do_tema'], 3)
        self.assertGreaterEqual(c['urgencia'], 2)

    def test_23_lingua_real(self):
        for t in ['qa', 'chat', 'teste']:
            self.assertGreaterEqual(self.qualidade['corpus'][t]['perguntas_lingua_real_percentual'], 30)
        self.assertTrue(any('oq ' in e['instruction'].lower() for e in self.dados['qa']))
        self.assertTrue(any(e['instruction'].isupper() for e in self.dados['qa']))

    def test_24_duplicatas_normalizadas(self):
        limpos, n = sem_duplicatas([{'text': '  Ação pública  '}, {'text': 'Ação   pública'}, {'text': 'Outra ação'}], 'text')
        self.assertEqual(n, 1)
        self.assertEqual(len(limpos), 2)
        for t, campo in [('texto', 'text'), ('qa', 'instruction'), ('teste', 'pergunta')]:
            _, n = sem_duplicatas(self.dados[t], campo)
            self.assertEqual(n, 0)

    def test_25_estatisticas_e_cinco_amostras(self):
        for t, exemplos in self.dados.items():
            s = self.qualidade['corpus'][t]
            self.assertEqual(s['exemplos'], len(exemplos))
            self.assertEqual(len(s['exemplos_aleatorios']), 5)
            self.assertGreater(s['media_tokens'], 0)

    def test_26_rejeita_fonte_alterada_sem_publicar(self):
        with tempfile.TemporaryDirectory() as pasta:
            p = Path(pasta)
            (p / 'curadoria').symlink_to(RAIZ / 'curadoria', target_is_directory=True)
            (p / 'entrada/fontes').mkdir(parents=True)
            (p / 'entrada/metadados.json').write_bytes((RAIZ / 'entrada/metadados.json').read_bytes())
            (p / 'entrada/fontes/chuvas_saude.pdf').write_bytes(b'arquivo alterado')
            with self.assertRaisesRegex(ValueError, 'foi alterada'):
                gerar(p, p / 'resultado')
            self.assertFalse((p / 'resultado/corpus_qa.jsonl').exists())

    def test_27_corpus_sem_identificadores_detectaveis(self):
        for t, rows in self.dados.items():
            for e in rows:
                campos = [e['text']] if t == 'texto' else [e['instruction'], e['input'], e['output'], e['trecho']] if t == 'qa' else [m['content'] for m in e['messages']] if t == 'chat' else [e['pergunta'], e['resposta_esperada']]
                for campo in campos:
                    for tipo, padrao in PADROES.items():
                        self.assertIsNone(padrao.search(campo), (t, e['id'], tipo))

    def test_28_upload_dos_tres_pdfs(self):
        enviados = {m['arquivo']: (RAIZ / 'entrada/fontes' / m['arquivo']).read_bytes() for m in self.meta}
        q, resultados = gerar_enviados(enviados)
        self.assertEqual(q['paginas_totais'], 92)
        for tipo in ['texto', 'qa', 'chat', 'teste']:
            nome = f'corpus_{tipo}.jsonl'
            self.assertEqual(resultados[nome], (RAIZ / 'saida' / nome).read_bytes())

    def test_29_upload_incompleto(self):
        with self.assertRaisesRegex(ValueError, 'três arquivos'):
            gerar_enviados({'chuvas_saude.pdf': b'incompleto'})

    def test_30_arquivo_enviado_alterado(self):
        enviados = {m['arquivo']: (RAIZ / 'entrada/fontes' / m['arquivo']).read_bytes() for m in self.meta}
        enviados['chuvas_saude.pdf'] += b'alterado'
        with self.assertRaisesRegex(ValueError, 'foi alterada'):
            gerar_enviados(enviados)

    def test_31_textos_de_atendimento_sem_mascara_indevida(self):
        for e in self.dados['qa']:
            self.assertNotIn('[NOME]', e['instruction'], e['id'])
            self.assertNotIn('[NOME]', e['output'], e['id'])
        for e in self.dados['chat']:
            for m in e['messages']:
                if m['role'] != 'system':
                    self.assertNotIn('[NOME]', m['content'], e['id'])


    def test_32_apoios_complementares_sem_mudar_teste(self):
        referencias = ler_json(RAIZ / 'saida/apoios_revisao.json')
        self.assertEqual({e['id'] for e in referencias}, {'T04', 'T08', 'T11', 'T17', 'T21', 'CHAT30'})
        for referencia in referencias:
            for apoio in referencia['apoios']:
                meta = next(m for m in self.meta if m['arquivo'] == apoio['fonte'])
                blocos, _ = preparar_documento((RAIZ / 'entrada/fontes' / meta['arquivo']).read_bytes(), meta, self.nlp)
                pagina = next(b for b in blocos if b['pagina'] == apoio['pagina'])
                self.assertTrue(apoio['trecho'])
                self.assertEqual(apoio['trecho'], pagina['texto'])
        conversa = next(e for e in self.dados['chat'] if e['id'] == 'CHAT30')
        self.assertTrue(any(a['pagina'] == 8 and '192' in a['trecho'] for a in conversa['apoios']))
        self.assertEqual(self.dados['teste'], ler_jsonl(RAIZ / 'curadoria/teste_fixo.jsonl'))

    def test_33_recomposicao_tipografica_conferida(self):
        self.assertEqual(normalizar('T êm calçamento? T ente chamar moradores.'),
                         'Têm calçamento? Tente chamar moradores.')
        self.assertEqual(normalizar('T e M são letras.'), 'T e M são letras.')


if __name__ == '__main__':
    unittest.main(verbosity=2)
