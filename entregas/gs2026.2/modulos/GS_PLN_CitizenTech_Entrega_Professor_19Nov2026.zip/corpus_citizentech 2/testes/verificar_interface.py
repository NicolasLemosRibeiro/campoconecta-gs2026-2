import json,sys,time
from pathlib import Path
from streamlit.testing.v1 import AppTest
p=Path(__file__).resolve().parents[1];sys.path.insert(0,str(p))
checks=[]
def registrar(nome, condicao):
 if not condicao:raise AssertionError(nome)
 checks.append(dict(teste=nome,status='aprovado'))
a=AppTest.from_file(str(p/'app.py')).run(timeout=60)
registrar('Carregamento inicial sem exceções',not a.exception)
print('buttons',[(i,b.label) for i,b in enumerate(a.button)],flush=True)
a.button[0].click().run(timeout=90)
registrar('Geração pela interface',not a.exception and len(a.success)>0)
registrar('Quatro corpus nas estatísticas',any(len(x.value)==4 for x in a.dataframe))
a.radio[0].set_value('Enviar os três documentos').run()
a.button[0].click().run(timeout=30)
registrar('Erro de upload incompleto tratado',not a.exception and any('três arquivos' in e.value for e in a.error))
# Formulário de texto colado, passando por extração e anonimização reais.
print('areas',[(i,x.label) for i,x in enumerate(a.text_area)],flush=True)
texto='Nome: Marina Ferreira Campos\nCPF: 000.111.222-33\nE-mail: marina.campos@example.invalid\nTelefone: (11) 90000-0000'
for x in a.text_area:
 if x.label=='Ou cole um texto':x.set_value(texto)
for x in a.text_input:
 if x.label=='Título':x.set_value('Teste sintético')
 elif x.label=='Órgão emissor':x.set_value('Grupo do projeto')
 elif x.label=='Link de origem':x.set_value('https://example.invalid/documento-ficticio')
 elif x.label=='Data de publicação ou vigência':x.set_value('2026-11-12')
for x in a.checkbox:
 if x.label.startswith('Documento fictício'):x.check()
for x in a.button:
 if x.label=='Processar entrada':x.click()
a.run(timeout=60)
registrar('Processamento de texto colado sem exceções',not a.exception)
tratado=[x.value for x in a.text_area if x.label=='Texto tratado']
registrar('Anonimização no formulário',bool(tratado) and '[NOME]' in tratado[0] and 'Marina' not in tratado[0] and '[CPF]' in tratado[0])
registrar('Bloqueio de exportação de documento fictício',any('Não será exportado' in x.value for x in a.info))
registrar('Revisão disponível na interface',len(a.get('data_editor'))>0 or len(a.dataframe)>=2)
(p/'evidencias').mkdir(exist_ok=True)
(p/'evidencias/interface.json').write_text(json.dumps(dict(testes=checks,resultado='aprovado'),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2))
