"""Confere recursos e repete a geração com conexões externas bloqueadas."""
from hashlib import sha256
from importlib.metadata import version
import json
import platform
from pathlib import Path
import sys
import tempfile
import time
from unittest.mock import patch

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
from fabrica import carregar_recursos, gerar, ler_json


def main():
    recursos = ler_json(RAIZ / 'recursos/manifesto.json')
    for nome, esperado in recursos['arquivos'].items():
        assert sha256((RAIZ / 'recursos' / nome).read_bytes()).hexdigest() == esperado, nome
    carregar_recursos()
    inicio = time.perf_counter()
    with tempfile.TemporaryDirectory() as pasta:
        with patch('socket.socket.connect', side_effect=RuntimeError('Conexões externas bloqueadas no teste')) as conexoes, \
             patch('socket.socket.connect_ex', side_effect=RuntimeError('Conexões externas bloqueadas no teste')) as conexoes_ex:
            gerar(RAIZ, Path(pasta) / 'saida')
            assert conexoes.call_count == 0 and conexoes_ex.call_count == 0
        arquivos = {}
        for nome in ['corpus_texto.jsonl', 'corpus_qa.jsonl', 'corpus_chat.jsonl', 'corpus_teste.jsonl']:
            original = (RAIZ / 'saida' / nome).read_bytes()
            repetido = (Path(pasta) / 'saida' / nome).read_bytes()
            assert repetido == original, f'Reprodução diferente em {nome}'
            arquivos[nome] = sha256(original).hexdigest()
    resultado = dict(resultado='aprovado', recursos_conferidos=len(recursos['arquivos']),
                     conexoes_externas='bloqueadas durante a geração',
                     segundos=round(time.perf_counter() - inicio, 2),
                     comparacao='Quatro JSONL idênticos byte a byte em nova geração.',
                     python=platform.python_version(), plataforma=platform.platform(),
                     bibliotecas={p: version(p) for p in ['spacy', 'transformers', 'pypdf', 'streamlit', 'pandas']},
                     sha256=arquivos)
    (RAIZ / 'evidencias').mkdir(exist_ok=True)
    (RAIZ / 'evidencias/reproducao.json').write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(resultado, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
