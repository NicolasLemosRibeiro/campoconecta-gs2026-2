# Evidências do gargalo no protótipo

O JSON resume um registro histórico do CampoConecta, omitindo caminhos pessoais locais. O hash identifica os bytes originais. O lote de 52 relatos processados é diferente do teste de 20 casos rotulados; suas métricas não devem ser misturadas.

Os arquivos triagem_origem.py e processar_origem.py são cópias das funções do protótipo para consulta, não uma instalação independente do backend. O teste rotulado é sintético.

A conferência de 17/11/2026 executou isoladamente a função triar_por_regras, seus padrões e funções auxiliares originais. Os adaptadores de saída apenas armazenaram os campos; não foi carregado LLM nem executado o backend completo. Houve 11 acertos de tipo e seis de urgência entre 20 exemplos. Isso não estima precisão populacional nem desempenho de um LLM configurado.
