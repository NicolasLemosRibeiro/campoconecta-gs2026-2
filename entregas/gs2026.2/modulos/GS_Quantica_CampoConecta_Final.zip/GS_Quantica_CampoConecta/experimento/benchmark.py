"""Experimento clássico para a GS de Quântica do CampoConecta.

Cada visita ocupa um turno e sai/retorna à base. São cenários sintéticos,
sem dados do produtor, sem roteirização multi-parada e sem execução quântica.
"""
import csv
import math
import platform
import random
import statistics
import sys
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import numpy as np
import scipy
from scipy.optimize import linear_sum_assignment

SEMENTES = range(420, 440)
CENARIOS = {"normal": 12, "pico": 48, "severo": 96}
PESOS = {"alta": 5, "media": 2, "baixa": 1}
PRAZOS = {"alta": 1, "media": 2, "baixa": 4}
DURACAO = {"praga_doenca": 90, "clima_extremo": 65, "agua_irrigacao": 55}
EQUIPES = [
    (4, {"praga_doenca", "agua_irrigacao"}),
    (13, {"praga_doenca", "clima_extremo"}),
    (30, {"clima_extremo", "agua_irrigacao"}),
    (42, {"praga_doenca", "clima_extremo", "agua_irrigacao"}),
]
DIAS = 6
TURNOS = 2
LIMITE_MIN = 180
IMPOSSIVEL = 10**9


@dataclass(frozen=True)
class Visita:
    tipo: str
    prioridade: str
    zona: str
    km: int


@dataclass(frozen=True)
class Turno:
    tecnico: int
    dia: int
    periodo: int


def gerar_lote(semente, quantidade):
    rng = random.Random(semente)
    visitas = []
    for _ in range(quantidade):
        tipo = rng.choices(tuple(DURACAO), weights=(4, 3, 3))[0]
        prioridade = rng.choices(tuple(PESOS), weights=(2, 5, 3))[0]
        zona = rng.choices(("proxima", "distante"), weights=(6, 4))[0]
        km = rng.randint(0, 28) if zona == "proxima" else rng.randint(34, 66)
        visitas.append(Visita(tipo, prioridade, zona, km))
    return visitas


def custo_sem_visita(visita):
    return 2000 * PESOS[visita.prioridade]


def dados_turno(visita, turno):
    base, habilitacoes = EQUIPES[turno.tecnico]
    distancia = 2 * abs(visita.km - base)
    duracao = DURACAO[visita.tipo] + math.ceil(1.6 * distancia)
    if visita.tipo not in habilitacoes or duracao > LIMITE_MIN:
        return IMPOSSIVEL, distancia
    peso = PESOS[visita.prioridade]
    atraso = max(0, turno.dia - PRAZOS[visita.prioridade])
    custo = distancia + peso * (3 * turno.dia + 30 * atraso)
    return custo, distancia


def agenda_gulosa(visitas, turnos):
    livres = set(range(len(turnos)))
    agenda = {}
    ordem = sorted(range(len(visitas)), key=lambda i: -PESOS[visitas[i].prioridade])
    for i in ordem:
        visita = visitas[i]
        escolhas = []
        for j in livres:
            turno = turnos[j]
            custo, km = dados_turno(visita, turno)
            if custo != IMPOSSIVEL:
                escolhas.append((turno.dia, turno.periodo, km, j))
        if escolhas:
            _, _, _, j = min(escolhas)
            agenda[i] = j
            livres.remove(j)
    return agenda


def agenda_exata(visitas, turnos):
    # Uma coluna extra por chamado permite deixar qualquer chamado pendente.
    n, m = len(visitas), len(turnos)
    custos = np.empty((n, m + n), dtype=np.int64)
    for i, visita in enumerate(visitas):
        custos[i, :m] = [dados_turno(visita, turno)[0] for turno in turnos]
        custos[i, m:] = custo_sem_visita(visita)
    linhas, colunas = linear_sum_assignment(custos)
    return {int(i): int(j) for i, j in zip(linhas, colunas) if j < m}


def avaliar(visitas, turnos, agenda):
    assert len(set(agenda.values())) == len(agenda), "Turno reservado duas vezes"
    custo_total = distancia = no_prazo = altas_prazo = distantes_prazo = proximas_prazo = 0
    for i, visita in enumerate(visitas):
        if i not in agenda:
            custo_total += custo_sem_visita(visita)
            continue
        turno = turnos[agenda[i]]
        custo, km = dados_turno(visita, turno)
        assert custo != IMPOSSIVEL, "Alocação incompatível"
        custo_total += custo
        distancia += km
        if turno.dia <= PRAZOS[visita.prioridade]:
            no_prazo += 1
            altas_prazo += visita.prioridade == "alta"
            distantes_prazo += visita.zona == "distante"
            proximas_prazo += visita.zona == "proxima"
    return {
        "custo_objetivo": custo_total, "agendadas": len(agenda),
        "pendentes": len(visitas) - len(agenda), "no_prazo": no_prazo,
        "altas_prazo": altas_prazo, "altas_total": sum(v.prioridade == "alta" for v in visitas),
        "distantes_prazo": distantes_prazo, "distantes_total": sum(v.zona == "distante" for v in visitas),
        "proximas_prazo": proximas_prazo, "proximas_total": sum(v.zona == "proxima" for v in visitas),
        "km_estimados": distancia,
    }


def resumir(registros):
    saida = []
    for cenario, n in CENARIOS.items():
        for metodo in ("gulosa", "exata"):
            linhas = [r for r in registros if r["cenario"] == cenario and r["metodo"] == metodo]
            def percentual(numerador, denominador):
                return round(100 * sum(r[numerador] for r in linhas) / sum(r[denominador] for r in linhas), 2)

            saida.append({
                "cenario": cenario, "metodo": metodo, "repeticoes": len(linhas), "lote": n,
                "pendentes_media": round(statistics.mean(r["pendentes"] for r in linhas), 2),
                "no_prazo_pct": percentual("no_prazo", "lote"),
                "altas_no_prazo_pct": percentual("altas_prazo", "altas_total"),
                "distantes_no_prazo_pct": percentual("distantes_prazo", "distantes_total"),
                "proximas_no_prazo_pct": percentual("proximas_prazo", "proximas_total"),
                "km_medios": round(statistics.mean(r["km_estimados"] for r in linhas), 1),
                "custo_objetivo_medio": round(statistics.mean(r["custo_objetivo"] for r in linhas), 1),
                "tempo_mediano_ms": round(statistics.median(r["tempo_ms"] for r in linhas), 3),
                "tempo_max_ms": round(max(r["tempo_ms"] for r in linhas), 3),
            })
    return saida


def escrever_csv(caminho, linhas):
    with caminho.open("w", encoding="utf-8", newline="") as arquivo:
        writer = csv.DictWriter(arquivo, fieldnames=linhas[0])
        writer.writeheader()
        writer.writerows(linhas)


def main(destino):
    destino.mkdir(parents=True, exist_ok=True)
    turnos = [
        Turno(tecnico, dia, periodo)
        for dia in range(DIAS)
        for periodo in range(TURNOS)
        for tecnico in range(len(EQUIPES))
    ]
    resultados = []
    for cenario, n in CENARIOS.items():
        for semente in SEMENTES:
            visitas = gerar_lote(semente, n)
            custos = []
            for nome, funcao in (("gulosa", agenda_gulosa), ("exata", agenda_exata)):
                inicio = perf_counter()
                agenda = funcao(visitas, turnos)
                tempo_ms = (perf_counter() - inicio) * 1000
                metricas = avaliar(visitas, turnos, agenda)
                custos.append(metricas["custo_objetivo"])
                resultados.append({
                    "cenario": cenario, "lote": n, "semente": semente,
                    "metodo": nome, "tempo_ms": round(tempo_ms, 5), **metricas,
                })
            assert custos[1] <= custos[0], "A solução exata perdeu no seu próprio objetivo"

    escrever_csv(destino / "execucoes.csv", resultados)
    escrever_csv(destino / "resumo.csv", resumir(resultados))
    (destino / "ambiente.txt").write_text(
        f"Python {platform.python_version()} | NumPy {np.__version__} | "
        f"SciPy {scipy.__version__} | {platform.system()} {platform.machine()}\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path("resultados"))
