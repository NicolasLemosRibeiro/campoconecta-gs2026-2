# CampoConecta | experimento clássico de agendamento

Anexo da entrega de Computação Quântica e IA, GS 2026.2 (FIAP).

Este benchmark é ilustrativo: trata de visitas após a validação, não de classificação de textos nem da distribuição de revisões humanas proposta no relatório. Não mede diretamente o gargalo de precisão ou seu custo operacional.

O script compara duas políticas para a etapa proposta de agendamento de visitas técnicas. Ele usa os tipos do CampoConecta que, em um piloto, poderiam exigir visita. A geração é inteiramente sintética, incluindo zonas, distâncias, prioridades já validadas, equipe e capacidade. Não é necessário baixar o repositório, acessar a internet durante a execução ou fornecer credenciais.

## Reproduzir

Use Python 3.12. Crie um ambiente virtual e instale as dependências:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python benchmark.py resultados_novos
```

O diretório `resultados/` contém a execução usada no relatório. A pasta nova preserva os CSVs originais. Os resultados operacionais simulados são determinísticos para as 20 sementes especificadas por cenário. Tempos de execução variam com o ambiente.

- `execucoes.csv` contém 120 execuções: 3 volumes × 20 sementes × 2 métodos. As duas políticas recebem o mesmo lote para cada semente.
- `resumo.csv` consolida médias e percentuais. Para a pontualidade, o denominador inclui todos os chamados elegíveis, inclusive os que ficaram pendentes. Para os recortes, inclui todos os chamados daquele grupo.
- `ambiente.txt` registra as versões usadas. O cronômetro mede cada política de agenda, incluindo a preparação da matriz no método exato. A geração de dados, a avaliação de métricas e a escrita de arquivos ficam fora da medição.

## Interpretar

Os 48 turnos são 4 equipes × 2 turnos × 6 dias. Cada visita sai e retorna à base no mesmo turno. A distância é ida e volta sobre um eixo sintético; ela não representa estradas reais. A análise mede agendamento, não deslocamentos observados, visitas concluídas, roteirização com várias paradas ou desempenho quântico.

O método guloso representa uma política de referência, criada para o teste. Ele ordena por prioridade e ordem de entrada e escolhe o primeiro turno habilitado, com menor distância como desempate. A política exata minimiza o custo que soma distância, espera, atraso e pendências ponderadas. Esse custo é uma pontuação de decisão, não um valor em reais. A validação do script verifica exclusividade de turnos, habilitação, duração e que a solução exata nunca perde para a gulosa no objetivo escolhido.

## Verificação do protótipo original

No repositório original do CampoConecta (não incluído neste anexo de agendamento), o relatório `docs/validacao/rpa_relatorio_execucao.json` registra 36 sinalizações de revisão humana em 52 relatos sintéticos processados por regras. No projeto original, pode-se reproduzir a avaliação dos 20 casos separados:

```bash
cd backend
GEMINI_API_KEY='' GEMINI_MODEL='' python avaliar.py casos_novos_2
```

A revisão humana do fluxo textual e a agenda de visitas são etapas diferentes. Os números do protótipo não foram usados como se fossem dados históricos de atendimento em campo.
